'use strict';
const { tx } = require('./db');
const V = require('./validate');
const { bad, notFound, conflict } = require('./errors');
const auth = require('./auth');

// ---------------------------------------------------------------------------
// Lookups (reference data)
// ---------------------------------------------------------------------------
const LOOKUPS = {
  grants: { table: 'grants', label: 'Grant', order: 'sort_order, id', refs: [['budget_lines', 'grant_id'], ['transactions', 'grant_id'], ['mous', 'grant_id']] },
  countries: { table: 'countries', label: 'Country', order: 'is_bucket DESC, name COLLATE NOCASE', refs: [['budget_lines', 'country_id'], ['transactions', 'country_id'], ['mous', 'country_id']] },
  works: { table: 'workstreams', label: 'Workstream', order: 'sort_order, id', refs: [['budget_lines', 'workstream_id'], ['transactions', 'workstream_id']] },
  cats: { table: 'expense_categories', label: 'Expense category', order: 'sort_order, id', refs: [['transactions', 'category_id']] },
  ccys: { table: 'currencies', label: 'Currency', pk: 'code', order: 'code', refs: [['transactions', 'currency']] },
};
// The finance logic refers to these names, so they cannot be renamed or removed.
const RESERVED = { works: ['Salary'], cats: ['Partner disbursement'] };

const lk = (kind) => { const d = LOOKUPS[kind]; if (!d) throw notFound('Lookup list'); return d; };

function names(db, kind) {
  const d = lk(kind);
  return db.prepare(`SELECT ${d.pk || 'name'} AS n FROM ${d.table} ORDER BY ${d.order}`).all().map((r) => r.n);
}
function idOf(db, kind, name, field) {
  const d = lk(kind);
  if (V.blank(name)) throw bad(`${field}: ${d.label.toLowerCase()} is required`, field);
  const row = d.pk
    ? db.prepare(`SELECT code AS id FROM currencies WHERE code=?`).get(String(name).toUpperCase())
    : db.prepare(`SELECT id FROM ${d.table} WHERE name=?`).get(String(name).trim());
  if (!row) throw bad(`${field}: unknown ${d.label.toLowerCase()} "${name}"`, field);
  return row.id;
}
const optId = (db, kind, name, field) => (V.blank(name) ? null : idOf(db, kind, name, field));

function addLookup(db, kind, name) {
  const d = lk(kind);
  let n = V.text(name, 'name', { max: 100, required: true });
  if (kind === 'ccys') {
    n = n.toUpperCase();
    if (!/^[A-Z]{3}$/.test(n)) throw bad('Currency codes are 3 letters, e.g. USD', 'name');
  }
  if (db.prepare(`SELECT 1 FROM ${d.table} WHERE ${d.pk || 'name'}=?`).get(n)) throw conflict(`${d.label} "${n}" already exists`);
  if (d.pk) db.prepare('INSERT INTO currencies(code) VALUES (?)').run(n);
  else {
    const so = d.table === 'countries' ? null : db.prepare(`SELECT COALESCE(MAX(sort_order),0)+1 AS s FROM ${d.table}`).get().s;
    if (so == null) db.prepare('INSERT INTO countries(name) VALUES (?)').run(n);
    else db.prepare(`INSERT INTO ${d.table}(name, sort_order) VALUES (?,?)`).run(n, so);
  }
  return n;
}

function renameLookup(db, kind, oldName, newName) {
  const d = lk(kind);
  if (kind === 'ccys') throw bad('Currency codes cannot be renamed. Add the new code and remove the old one.');
  if ((RESERVED[kind] || []).includes(oldName)) throw conflict(`"${oldName}" is used by the system and cannot be renamed`);
  const id = idOf(db, kind, oldName, 'name');
  const n = V.text(newName, 'name', { max: 100, required: true });
  const dup = db.prepare(`SELECT id FROM ${d.table} WHERE name=? AND id<>?`).get(n, id);
  if (dup) throw conflict(`${d.label} "${n}" already exists`);
  db.prepare(`UPDATE ${d.table} SET name=? WHERE id=?`).run(n, id);
  return n;
}

function deleteLookup(db, kind, name) {
  const d = lk(kind);
  if ((RESERVED[kind] || []).includes(name)) throw conflict(`"${name}" is used by the system and cannot be removed`);
  const id = idOf(db, kind, name, 'name');
  if (kind === 'countries' && db.prepare('SELECT is_bucket FROM countries WHERE id=?').get(id).is_bucket) throw conflict('The non-country bucket cannot be removed');
  if (kind === 'ccys' && getSettings(db).rep === id) throw conflict('The reporting currency cannot be removed');
  for (const [t, col] of d.refs) {
    const n = db.prepare(`SELECT COUNT(*) AS n FROM ${t} WHERE ${col}=?`).get(id).n;
    if (n) throw conflict(`"${name}" is used by ${n} record(s) in ${t.replace('_', ' ')} and cannot be removed`);
  }
  db.prepare(`DELETE FROM ${d.table} WHERE ${d.pk || 'id'}=?`).run(id);
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
function getSettings(db) {
  const m = Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map((r) => [r.key, r.value]));
  return {
    rep: m.reporting_currency || 'AUD',
    pct: [1, 2, 3].map((i) => (m['milestone_pct_' + i] != null ? +m['milestone_pct_' + i] : [0.3, 0.3, 0.4][i - 1])),
    cpa: m.cpa_total == null || m.cpa_total === '' ? null : +m.cpa_total,
  };
}
const setSetting = (db, k, v) => db.prepare('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, String(v));

function updateSettings(db, body) {
  V.requireObject(body);
  const before = getSettings(db);
  const out = { warnings: [] };
  if ('rep' in body) {
    const code = String(body.rep || '').trim().toUpperCase();
    idOf(db, 'ccys', code, 'rep');
    setSetting(db, 'reporting_currency', code);
    const n = db.prepare(`SELECT COUNT(*) AS n FROM transactions WHERE currency<>? AND (fx_rate IS NULL)`).get(code).n;
    if (n) out.warnings.push(`${n} transaction(s) are not in ${code} and have no FX rate; they count as 0 until a rate is entered.`);
  }
  if ('pct' in body) {
    const p = body.pct;
    if (!Array.isArray(p) || p.length !== 3 || p.some((x) => typeof x !== 'number' || !Number.isFinite(x) || x < 0 || x > 1)) throw bad('Milestone shares must be three numbers between 0% and 100%', 'pct');
    p.forEach((x, i) => setSetting(db, 'milestone_pct_' + (i + 1), Math.round(x * 10000) / 10000));
    if (Math.abs(p[0] + p[1] + p[2] - 1) > 1e-4) out.warnings.push('Milestone shares do not total 100%.');
  }
  if ('cpa' in body) {
    if (V.blank(body.cpa)) setSetting(db, 'cpa_total', '');
    else setSetting(db, 'cpa_total', V.money(body.cpa, 'cpa') / 100);
  }
  out.settings = getSettings(db);
  out.before = before;
  return out;
}

// ---------------------------------------------------------------------------
// Transactions
// ---------------------------------------------------------------------------
const TXN_SELECT = `SELECT t.*, g.name AS g, c.name AS c, w.name AS w, k.name AS cat
  FROM transactions t JOIN grants g ON g.id=t.grant_id JOIN countries c ON c.id=t.country_id
  LEFT JOIN workstreams w ON w.id=t.workstream_id LEFT JOIN expense_categories k ON k.id=t.category_id`;

const txnOut = (r) => ({
  id: r.id, type: r.txn_type, date: r.txn_date || '', g: r.g, c: r.c, w: r.w || '', cat: r.cat || '', ms: r.milestone || '',
  d: r.description, staff: r.staff_name || '', ccy: r.currency, amt: r.amount_minor / 100, fx: r.fx_rate == null ? '' : r.fx_rate,
  st: r.status, due: r.due_date || '', pdate: r.payment_date || '', doc: r.doc_ref, ver: r.verified ? 'Yes' : 'No',
});
const getTxn = (db, id) => { const r = db.prepare(TXN_SELECT + ' WHERE t.id=?').get(id); return r ? txnOut(r) : null; };
const listTxns = (db) => db.prepare(TXN_SELECT + ' ORDER BY t.id').all().map(txnOut);

const TXN_KEYS = ['type', 'date', 'g', 'c', 'w', 'cat', 'ms', 'd', 'staff', 'ccy', 'amt', 'fx', 'st', 'due', 'pdate', 'doc', 'ver'];

/** Validate a full transaction (API shape) and return DB column values. */
function normTxn(db, m) {
  const rep = getSettings(db).rep;
  const type = V.oneOf(m.type, ['Income', 'Expenditure'], 'type');
  const inc = type === 'Income';
  const date = V.date(m.date, 'date');
  const bucket = db.prepare('SELECT id FROM countries WHERE is_bucket=1').get();
  const grant = idOf(db, 'grants', m.g, 'g');
  const country = inc && V.blank(m.c) ? bucket.id : idOf(db, 'countries', m.c, 'c');
  const ws = inc ? null : idOf(db, 'works', m.w, 'w');
  const cat = inc ? null : idOf(db, 'cats', m.cat, 'cat');
  const ms = inc ? null : V.oneOf(m.ms, ['M1', 'M2', 'M3', 'N/A'], 'ms', { optional: true });
  const ccy = idOf(db, 'ccys', m.ccy, 'ccy');
  const amt = V.money(m.amt, 'amt', { required: true });
  if (amt <= 0) throw bad('amt: amount must be greater than zero', 'amt');
  let fxr = V.fx(m.fx, 'fx');
  if (ccy !== rep && fxr == null) throw bad(`fx: an FX rate to ${rep} is required for ${ccy} amounts`, 'fx');
  if (ccy === rep) fxr = null;
  const st = inc ? 'Available' : V.oneOf(m.st, ['Outstanding', 'Paid'], 'st');
  const due = inc ? null : V.date(m.due, 'due');
  const pdate = inc ? null : V.date(m.pdate, 'pdate');
  if (date && pdate && pdate < date) throw bad('pdate: payment date cannot be before the invoice date', 'pdate');
  const ver = V.yesNo(V.blank(m.ver) ? 'No' : m.ver, 'ver');
  const staff = V.text(m.staff, 'staff', { max: 100 }) || null;
  return [type, date, grant, country, ws, cat, ms, V.text(m.d, 'd', { max: 500 }), staff, ccy, amt, fxr, st, due, pdate, V.text(m.doc, 'doc', { max: 100 }), ver];
}
const TXN_COLS = 'txn_type,txn_date,grant_id,country_id,workstream_id,category_id,milestone,description,staff_name,currency,amount_minor,fx_rate,status,due_date,payment_date,doc_ref,verified';
const pickTxn = (o) => Object.fromEntries(TXN_KEYS.filter((k) => k in o).map((k) => [k, o[k]]));

function createTxn(db, body, user) {
  V.requireObject(body);
  const p = normTxn(db, { ver: 'No', ...pickTxn(body) });
  const res = db.prepare(`INSERT INTO transactions(${TXN_COLS}, created_by) VALUES (${p.map(() => '?').join(',')},?)`).run(...p, user ? user.id : null);
  return getTxn(db, Number(res.lastInsertRowid));
}
function updateTxn(db, id, body) {
  V.requireObject(body);
  const cur = getTxn(db, id);
  if (!cur) throw notFound('Transaction');
  const patch = pickTxn(body);
  if ('type' in patch && patch.type !== cur.type) throw bad('type: a transaction cannot change between Income and Expenditure. Delete and re-enter it.', 'type');
  const merged = { ...cur, ...patch };
  const p = normTxn(db, merged);
  db.prepare(`UPDATE transactions SET ${TXN_COLS.split(',').map((c) => c + '=?').join(',')}, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`).run(...p, id);
  return { before: cur, after: getTxn(db, id) };
}
function deleteTxn(db, id) {
  const cur = getTxn(db, id);
  if (!cur) throw notFound('Transaction');
  db.prepare('DELETE FROM transactions WHERE id=?').run(id);
  return cur;
}

// ---------------------------------------------------------------------------
// Budget lines
// ---------------------------------------------------------------------------
const BUD_SELECT = `SELECT b.*, g.name AS g, c.name AS c, w.name AS w FROM budget_lines b
  JOIN grants g ON g.id=b.grant_id JOIN countries c ON c.id=b.country_id JOIN workstreams w ON w.id=b.workstream_id`;
const budOut = (r) => ({ id: r.id, g: r.g, c: r.c, w: r.w, d: r.description, staff: r.staff_name || '', a: r.amount_minor / 100 });
const getBud = (db, id) => { const r = db.prepare(BUD_SELECT + ' WHERE b.id=?').get(id); return r ? budOut(r) : null; };
const listBud = (db) => db.prepare(BUD_SELECT + ' ORDER BY b.id').all().map(budOut);

function normBud(db, m) {
  return [idOf(db, 'grants', m.g, 'g'), idOf(db, 'countries', m.c, 'c'), idOf(db, 'works', m.w, 'w'),
    V.text(m.d, 'd', { max: 500 }), V.text(m.staff, 'staff', { max: 100 }) || null, V.money(m.a, 'a')];
}
const BUD_COLS = 'grant_id,country_id,workstream_id,description,staff_name,amount_minor';
const pickBud = (o) => Object.fromEntries(['g', 'c', 'w', 'd', 'staff', 'a'].filter((k) => k in o).map((k) => [k, o[k]]));

function createBud(db, body) {
  V.requireObject(body);
  const p = normBud(db, { d: '', a: 0, ...pickBud(body) });
  const r = db.prepare(`INSERT INTO budget_lines(${BUD_COLS}) VALUES (?,?,?,?,?,?)`).run(...p);
  return getBud(db, Number(r.lastInsertRowid));
}
function updateBud(db, id, body) {
  V.requireObject(body);
  const cur = getBud(db, id);
  if (!cur) throw notFound('Budget line');
  const p = normBud(db, { ...cur, ...pickBud(body) });
  db.prepare(`UPDATE budget_lines SET ${BUD_COLS.split(',').map((c) => c + '=?').join(',')}, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`).run(...p, id);
  return { before: cur, after: getBud(db, id) };
}
function deleteBud(db, id) {
  const cur = getBud(db, id);
  if (!cur) throw notFound('Budget line');
  db.prepare('DELETE FROM budget_lines WHERE id=?').run(id);
  return cur;
}

// ---------------------------------------------------------------------------
// MoU tracker
// ---------------------------------------------------------------------------
function listMous(db) {
  const ms = db.prepare('SELECT * FROM mou_milestones ORDER BY mou_id, seq').all();
  const by = new Map();
  ms.forEach((m) => { if (!by.has(m.mou_id)) by.set(m.mou_id, [{}, {}, {}]); by.get(m.mou_id)[m.seq - 1] = m; });
  return db.prepare(`SELECT m.*, c.name AS c, g.name AS g FROM mous m JOIN countries c ON c.id=m.country_id
    LEFT JOIN grants g ON g.id=m.grant_id ORDER BY m.id`).all().map((r) => {
    const arr = by.get(r.id) || [{}, {}, {}];
    return {
      id: r.id, c: r.c, p: r.partner_name, em: r.partner_email, g: r.g || '', s: r.start_date || '', e: r.end_date || '',
      f: r.agreed_minor / 100, act: r.next_action, who: r.owner,
      due: arr.map((m) => m.due_date || ''), conf: arr.map((m) => (m.docs_confirmed == null ? '' : m.docs_confirmed ? 'Yes' : 'No')),
    };
  });
}
const getMou = (db, id) => listMous(db).find((m) => m.id === id) || null;

function normMou(db, m) {
  const bucket = db.prepare('SELECT name FROM countries WHERE is_bucket=1').get().name;
  if (m.c === bucket) throw bad(`c: an MoU must be with a specific country, not "${bucket}"`, 'c');
  const country = idOf(db, 'countries', m.c, 'c');
  const grant = optId(db, 'grants', m.g, 'g');
  const s = V.date(m.s, 's'), e = V.date(m.e, 'e');
  if (s && e && e < s) throw bad('e: MoU end date cannot be before the start date', 'e');
  const due = Array.isArray(m.due) && m.due.length === 3 ? m.due : null;
  const conf = Array.isArray(m.conf) && m.conf.length === 3 ? m.conf : null;
  if (!due || !conf) throw bad('due and conf must each have 3 entries (M1, M2, M3)', 'due');
  return {
    row: [country, V.text(m.p, 'p', { max: 200 }), V.email(m.em, 'em'), grant, s, e, V.money(m.f, 'f'), V.text(m.act, 'act', { max: 500 }), V.text(m.who, 'who', { max: 100 })],
    due: due.map((d, i) => V.date(d, `due[${i}]`)),
    conf: conf.map((c, i) => (V.blank(c) ? null : V.yesNo(c, `conf[${i}]`))),
  };
}
const MOU_COLS = 'country_id,partner_name,partner_email,grant_id,start_date,end_date,agreed_minor,next_action,owner';
function saveMilestones(db, id, n) {
  for (let i = 0; i < 3; i++) {
    db.prepare(`INSERT INTO mou_milestones(mou_id,seq,due_date,docs_confirmed) VALUES (?,?,?,?)
      ON CONFLICT(mou_id,seq) DO UPDATE SET due_date=excluded.due_date, docs_confirmed=excluded.docs_confirmed`).run(id, i + 1, n.due[i], n.conf[i]);
  }
}
const MOU_KEYS = ['c', 'p', 'em', 'g', 's', 'e', 'f', 'act', 'who', 'due', 'conf'];
const pickMou = (o) => Object.fromEntries(MOU_KEYS.filter((k) => k in o).map((k) => [k, o[k]]));
const dupMou = (e) => (/UNIQUE/i.test(String(e.message)) ? conflict('That country already has an MoU row') : e);

function createMou(db, body) {
  V.requireObject(body);
  const n = normMou(db, { p: '', em: '', g: '', s: '', e: '', f: 0, act: '', who: '', due: ['', '', ''], conf: ['', '', ''], ...pickMou(body) });
  try {
    const r = db.prepare(`INSERT INTO mous(${MOU_COLS}) VALUES (?,?,?,?,?,?,?,?,?)`).run(...n.row);
    const id = Number(r.lastInsertRowid);
    saveMilestones(db, id, n);
    return getMou(db, id);
  } catch (e) { throw dupMou(e); }
}
function updateMou(db, id, body) {
  V.requireObject(body);
  const cur = getMou(db, id);
  if (!cur) throw notFound('MoU');
  const n = normMou(db, { ...cur, ...pickMou(body) });
  try {
    db.prepare(`UPDATE mous SET ${MOU_COLS.split(',').map((c) => c + '=?').join(',')}, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`).run(...n.row, id);
    saveMilestones(db, id, n);
  } catch (e) { throw dupMou(e); }
  return { before: cur, after: getMou(db, id) };
}
function deleteMou(db, id) {
  const cur = getMou(db, id);
  if (!cur) throw notFound('MoU');
  db.prepare('DELETE FROM mous WHERE id=?').run(id);
  return cur;
}

// ---------------------------------------------------------------------------
// State snapshot (shape consumed by shared/finance.js)
// ---------------------------------------------------------------------------
function getState(db) {
  const s = getSettings(db);
  return {
    ...s,
    L: { grants: names(db, 'grants'), countries: names(db, 'countries'), works: names(db, 'works'), cats: names(db, 'cats'), ccys: names(db, 'ccys') },
    bud: listBud(db), reg: listTxns(db), trk: listMous(db),
  };
}

// ---------------------------------------------------------------------------
// Users & audit
// ---------------------------------------------------------------------------
const userOut = (u) => ({ id: u.id, username: u.username, name: u.display_name, role: u.role, active: !!u.active });
const listUsers = (db) => db.prepare('SELECT * FROM users ORDER BY id').all().map(userOut);
const ROLES = ['admin', 'editor', 'viewer'];

function createUser(db, body) {
  V.requireObject(body);
  const username = V.text(body.username, 'username', { max: 60, required: true });
  if (username.length < 3 || !/^[A-Za-z0-9._@-]+$/.test(username)) throw bad('username: 3+ characters, letters, numbers and . _ @ - only', 'username');
  auth.checkPasswordStrength(body.password);
  const role = V.oneOf(body.role, ROLES, 'role');
  if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username)) throw conflict('That username is already taken');
  const r = db.prepare('INSERT INTO users(username,display_name,password_hash,role) VALUES (?,?,?,?)')
    .run(username, V.text(body.name, 'name', { max: 100 }), auth.hashPassword(body.password), role);
  return userOut(db.prepare('SELECT * FROM users WHERE id=?').get(Number(r.lastInsertRowid)));
}
function updateUser(db, id, body, actingId) {
  V.requireObject(body);
  const cur = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if (!cur) throw notFound('User');
  const role = 'role' in body ? V.oneOf(body.role, ROLES, 'role') : cur.role;
  const active = 'active' in body ? (body.active ? 1 : 0) : cur.active;
  const losesAdmin = cur.role === 'admin' && cur.active && (role !== 'admin' || !active);
  if (losesAdmin && db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='admin' AND active=1").get().n <= 1) throw conflict('There must always be at least one active administrator');
  if (id === actingId && !active) throw conflict('You cannot deactivate your own account');
  let hash = cur.password_hash;
  if ('password' in body && !V.blank(body.password)) { auth.checkPasswordStrength(body.password); hash = auth.hashPassword(body.password); }
  const name = 'name' in body ? V.text(body.name, 'name', { max: 100 }) : cur.display_name;
  db.prepare('UPDATE users SET role=?, active=?, password_hash=?, display_name=? WHERE id=?').run(role, active, hash, name, id);
  if (!active || hash !== cur.password_hash || role !== cur.role) db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);
  return { before: userOut(cur), after: userOut(db.prepare('SELECT * FROM users WHERE id=?').get(id)) };
}

function audit(db, user, entity, entityId, action, before, after) {
  db.prepare('INSERT INTO audit_log(user_id,username,entity,entity_id,action,before_json,after_json) VALUES (?,?,?,?,?,?,?)')
    .run(user ? user.id : null, user ? user.username : '', entity, String(entityId == null ? '' : entityId), action,
      before == null ? null : JSON.stringify(before), after == null ? null : JSON.stringify(after));
}
function listAudit(db, { limit = 200, entity, entityId } = {}) {
  const w = [], a = [];
  if (entity) { w.push('entity=?'); a.push(entity); }
  if (entityId) { w.push('entity_id=?'); a.push(String(entityId)); }
  const lim = Math.min(Math.max(parseInt(limit, 10) || 200, 1), 1000);
  return db.prepare(`SELECT * FROM audit_log ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY id DESC LIMIT ${lim}`).all(...a)
    .map((r) => ({ id: r.id, ts: r.ts, user: r.username, entity: r.entity, entityId: r.entity_id, action: r.action, before: r.before_json && JSON.parse(r.before_json), after: r.after_json && JSON.parse(r.after_json) }));
}

module.exports = {
  tx, LOOKUPS, RESERVED, names, addLookup, renameLookup, deleteLookup,
  getSettings, updateSettings, getState,
  listTxns, getTxn, createTxn, updateTxn, deleteTxn,
  listBud, getBud, createBud, updateBud, deleteBud,
  listMous, getMou, createMou, updateMou, deleteMou,
  listUsers, createUser, updateUser, audit, listAudit,
};
