'use strict';
const fs = require('node:fs');
const path = require('node:path');
const store = require('./store');
const { tx } = require('./db');

const read = (f) => JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', f), 'utf8'));

/** Load the opening reference data, budget, MoU rows and opening transactions. Idempotent guard: refuses on a non-empty DB. */
function seedOpening(db, data = read('opening-data.json'), world = read('world-countries.json')) {
  if (db.prepare('SELECT COUNT(*) AS n FROM grants').get().n) throw new Error('Database already contains data; refusing to seed.');
  tx(db, () => {
    const put = (k, v) => db.prepare('INSERT INTO settings(key,value) VALUES (?,?)').run(k, String(v));
    put('reporting_currency', data.rep);
    data.pct.forEach((p, i) => put('milestone_pct_' + (i + 1), p));
    put('cpa_total', data.cpa == null ? '' : data.cpa);
    data.L.ccys.forEach((c) => db.prepare('INSERT INTO currencies(code) VALUES (?)').run(c));
    data.L.grants.forEach((n) => store.addLookup(db, 'grants', n));
    data.L.works.forEach((n) => store.addLookup(db, 'works', n));
    data.L.cats.forEach((n) => store.addLookup(db, 'cats', n));
    const bucket = data.L.countries[0];
    db.prepare('INSERT INTO countries(name,is_bucket) VALUES (?,1)').run(bucket);
    [...new Set([...data.L.countries.slice(1), ...world])].filter((c) => c !== bucket).sort((a, b) => a.localeCompare(b)).forEach((n) => store.addLookup(db, 'countries', n));

    const staffOf = (w, d) => { const m = w === 'Salary' && /^Salary - ([A-Za-z]+)/.exec(d || ''); return m && m[1].toLowerCase() !== 'unallocated' ? m[1] : ''; };
    data.bud.forEach((b) => store.createBud(db, { g: b.g, c: b.c, w: b.w, d: b.d, a: b.a, staff: staffOf(b.w, b.d) }));
    data.trk.filter((t) => t.c).forEach((t) => store.createMou(db, { c: t.c, p: t.p, em: t.em, g: t.g, s: t.s, e: t.e, f: t.f, act: t.act, who: t.who, due: t.due, conf: t.conf }));
    data.reg.forEach((r) => store.createTxn(db, { ...r, staff: staffOf(r.w, r.d) }, null));
    store.audit(db, null, 'setting', 'seed', 'create', null, { source: 'opening-data.json' });
  });
}

/** Optional demo/UAT data: dated invoices, payments and MoU milestones relative to today (mirrors the original TEST seed). */
function seedDemo(db, todayStr) {
  const base = new Date(todayStr + 'T00:00:00Z');
  const R = (n) => { const d = new Date(base); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  tx(db, () => {
    const mous = store.listMous(db);
    [['Thailand', 0, -35, '', 'Partner University Thailand', 'thailand'], ['Brazil', 0, -12, '', 'Partner Institute Brazil', ''], ['Pakistan', 0, -5, '', 'Partner University Pakistan', 'pakistan'],
      ['India', 0, -30, 'Yes', 'Partner Institute India', 'india'], ['Kenya', 0, 10, '', 'Partner University Kenya', 'kenya'], ['Bangladesh', 0, 14, '', 'Partner Centre Bangladesh', 'bangladesh'],
      ['Colombia', 0, 20, '', 'Partner University Colombia', 'colombia'], ['Indonesia', 0, 26, '', 'Partner Institute Indonesia', 'indonesia'], ['South Africa', 0, 45, '', '', ''],
      ['Argentina', 0, 60, '', '', ''], ['Brazil', 1, 90, '', '', ''], ['Ghana', 0, 120, '', '', '']].forEach(([c, k, n, cf, p, em]) => {
      const m = mous.find((x) => x.c === c);
      if (!m) return;
      m.due[k] = R(n); if (cf) m.conf[k] = cf;
      store.updateMou(db, m.id, { due: m.due, conf: m.conf, ...(p ? { p } : {}), ...(em ? { em: em + '.partner@example.org' } : {}) });
    });
    const exp = (o) => store.createTxn(db, { type: 'Expenditure', g: 'PRG00626', w: 'Seed funding', cat: 'Partner disbursement', ccy: store.getSettings(db).rep, ver: 'No', ...o }, null);
    [['Kenya', 500, -15, 'TEST invoice - consultancy'], ['Bangladesh', 1200, -3, 'TEST invoice - printing'], ['Kenya', 750, 9, 'TEST invoice - training materials'], ['India', 2400, 21, 'TEST invoice - equipment'],
      ['Thailand', 1800, 27, 'TEST invoice - workshop'], ['Ghana', 900, 60, 'TEST invoice - later'], ['India', 300, null, 'TEST invoice - no due date']]
      .forEach(([c, amt, n, d]) => exp({ date: R(-45), c, amt, d, st: 'Outstanding', due: n == null ? '' : R(n) }));
    [[-175, 'NHMRC', 20000, 'TEST funding tranche 1'], [-100, 'PRG00626', 50000, 'TEST funding tranche 2'], [-30, 'SSEAC', 5000, 'TEST funding tranche 3']]
      .forEach(([n, g, amt, d]) => store.createTxn(db, { type: 'Income', date: R(n), g, amt, d, ccy: store.getSettings(db).rep }, null));
    [[-170, 'Thailand', 1500, 'Seed funding'], [-140, 'India', 2000, 'Seed funding'], [-110, 'Kenya', 2500, 'Seed funding'], [-80, 'Colombia', 1800, 'In-country training'],
      [-50, 'Brazil', 2200, 'Seed funding'], [-20, 'Pakistan', 1200, 'Seed funding'], [-8, 'Argentina', 3000, 'CP register expansion']]
      .forEach(([n, c, amt, w]) => exp({ date: R(n - 10), pdate: R(n), c, amt, w, d: 'TEST payment - ' + c, st: 'Paid' }));
    store.audit(db, null, 'setting', 'seed-demo', 'create', null, { demo: true });
  });
}

module.exports = { seedOpening, seedDemo };
