'use strict';
const crypto = require('node:crypto');
const { ApiError, bad } = require('./errors');

const N = 16384, KEYLEN = 64;
const SESSION_HOURS = 12;
const ROLE_RANK = { viewer: 1, editor: 2, admin: 3 };

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(pw, salt, KEYLEN, { N });
  return `scrypt$${N}$${salt.toString('hex')}$${h.toString('hex')}`;
}
function verifyPassword(pw, stored) {
  const [alg, n, salt, hash] = String(stored).split('$');
  if (alg !== 'scrypt') return false;
  const h = crypto.scryptSync(pw, Buffer.from(salt, 'hex'), KEYLEN, { N: +n });
  const b = Buffer.from(hash, 'hex');
  return h.length === b.length && crypto.timingSafeEqual(h, b);
}
function checkPasswordStrength(pw) {
  if (typeof pw !== 'string' || pw.length < 10) throw bad('Password must be at least 10 characters', 'password');
  if (pw.length > 200) throw bad('Password is too long', 'password');
}

const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');

function createSession(db, userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  const exp = new Date(Date.now() + SESSION_HOURS * 3600e3).toISOString();
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES (?,?,?)').run(sha(token), userId, exp);
  return { token, maxAgeSec: SESSION_HOURS * 3600 };
}
function destroySession(db, token) { if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(token)); }

function parseCookies(h) {
  const out = {};
  String(h || '').split(';').forEach((p) => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}

/** Attach req.user if a valid session cookie is present. */
function sessionMiddleware(db) {
  return (req, _res, next) => {
    const token = parseCookies(req.headers.cookie).sid;
    req.sessionToken = token || null;
    if (token) {
      const row = db.prepare(`SELECT u.id,u.username,u.display_name,u.role FROM sessions s JOIN users u ON u.id=s.user_id
        WHERE s.token_hash=? AND s.expires_at > ? AND u.active=1`).get(sha(token), new Date().toISOString());
      if (row) req.user = { id: row.id, username: row.username, name: row.display_name || row.username, role: row.role };
    }
    next();
  };
}

const requireRole = (min) => (req, _res, next) => {
  if (!req.user) return next(new ApiError(401, 'Please sign in'));
  if (ROLE_RANK[req.user.role] < ROLE_RANK[min]) return next(new ApiError(403, 'You do not have permission to do that'));
  next();
};

/** Tiny in-memory login throttle: 8 failures / 15 min per username+ip. */
function makeThrottle(max = 8, windowMs = 15 * 60e3) {
  const m = new Map();
  return {
    blocked(key) { const e = m.get(key); return !!e && e.n >= max && Date.now() - e.t < windowMs; },
    fail(key) { const e = m.get(key); if (!e || Date.now() - e.t >= windowMs) m.set(key, { n: 1, t: Date.now() }); else e.n++; },
    reset(key) { m.delete(key); },
  };
}

const cleanup = (db) => db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(new Date().toISOString());

module.exports = { hashPassword, verifyPassword, checkPasswordStrength, createSession, destroySession, sessionMiddleware, requireRole, makeThrottle, cleanup, ROLE_RANK };
