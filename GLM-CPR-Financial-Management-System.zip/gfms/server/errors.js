'use strict';
class ApiError extends Error {
  constructor(status, message, field) {
    super(message);
    this.status = status;
    this.field = field;
  }
}
const bad = (msg, field) => new ApiError(422, msg, field);
const notFound = (what) => new ApiError(404, `${what} not found`);
const conflict = (msg) => new ApiError(409, msg);
module.exports = { ApiError, bad, notFound, conflict };
