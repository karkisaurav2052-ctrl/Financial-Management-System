'use strict';
const path = require('node:path');
const { open } = require('./db');
const { createApp } = require('./app');

const file = process.env.DB_FILE || path.join(__dirname, '..', 'data', 'gfms.sqlite');
const port = Number(process.env.PORT) || 3000;
const host = process.env.HOST || '127.0.0.1';

const db = open(file);
const app = createApp(db, { trustProxy: process.env.TRUST_PROXY === '1' });
const server = app.listen(port, host, () => console.log(`GLM-CPR Financial Management System on http://${host}:${port} (db: ${file})`));

const stop = () => server.close(() => { db.close(); process.exit(0); });
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
