-- =====================================================================
-- GLM-CPR Financial Management System : database schema (SQLite dialect)
-- Money is stored as INTEGER minor units (cents) to avoid float drift.
-- All reference data is normalised; renaming a grant/country/etc. is a
-- single-row update and every report follows automatically.
-- =====================================================================

-- ---------- configuration -------------------------------------------
CREATE TABLE settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);                                   -- reporting_currency, milestone_pct_1..3, cpa_total

CREATE TABLE currencies (
  code TEXT PRIMARY KEY CHECK (length(code) = 3 AND code = upper(code))
);

CREATE TABLE grants (
  id         INTEGER PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(name)) > 0),
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE countries (
  id        INTEGER PRIMARY KEY,
  name      TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(name)) > 0),
  is_bucket INTEGER NOT NULL DEFAULT 0 CHECK (is_bucket IN (0,1))  -- 'Global' non-country bucket
);
CREATE UNIQUE INDEX one_bucket_country ON countries(is_bucket) WHERE is_bucket = 1;

CREATE TABLE workstreams (
  id         INTEGER PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(name)) > 0),
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE expense_categories (
  id         INTEGER PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(name)) > 0),
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- ---------- users, sessions, audit (defined early: FK targets) --------
CREATE TABLE users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(username) BETWEEN 3 AND 60),
  display_name  TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,                        -- scrypt$N$salt$hash
  role          TEXT NOT NULL CHECK (role IN ('admin','editor','viewer')),
  active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,                        -- sha256 of the cookie value
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  expires_at TEXT NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE audit_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ts          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  username    TEXT NOT NULL DEFAULT '',
  entity      TEXT NOT NULL,                          -- transaction | budget_line | mou | lookup | setting | user
  entity_id   TEXT NOT NULL DEFAULT '',
  action      TEXT NOT NULL CHECK (action IN ('create','update','delete','login','logout')),
  before_json TEXT,
  after_json  TEXT
);
CREATE INDEX idx_audit_entity ON audit_log(entity, entity_id);
CREATE INDEX idx_audit_ts     ON audit_log(ts);

-- ---------- budget ----------------------------------------------------
CREATE TABLE budget_lines (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  grant_id      INTEGER NOT NULL REFERENCES grants(id)      ON DELETE RESTRICT,
  country_id    INTEGER NOT NULL REFERENCES countries(id)   ON DELETE RESTRICT,
  workstream_id INTEGER NOT NULL REFERENCES workstreams(id) ON DELETE RESTRICT,
  description   TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 500),
  staff_name    TEXT CHECK (staff_name IS NULL OR length(staff_name) <= 100),  -- salary breakdown
  amount_minor  INTEGER NOT NULL DEFAULT 0 CHECK (amount_minor >= 0),
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_budget_grant      ON budget_lines(grant_id);
CREATE INDEX idx_budget_country    ON budget_lines(country_id);
CREATE INDEX idx_budget_workstream ON budget_lines(workstream_id);

-- ---------- MoU tracker -----------------------------------------------
CREATE TABLE mous (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  country_id    INTEGER NOT NULL UNIQUE REFERENCES countries(id) ON DELETE RESTRICT,
  partner_name  TEXT NOT NULL DEFAULT '' CHECK (length(partner_name) <= 200),
  partner_email TEXT NOT NULL DEFAULT '' CHECK (length(partner_email) <= 200),
  grant_id      INTEGER REFERENCES grants(id) ON DELETE SET NULL,
  start_date    TEXT CHECK (start_date IS NULL OR start_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  end_date      TEXT CHECK (end_date   IS NULL OR end_date   GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  agreed_minor  INTEGER NOT NULL DEFAULT 0 CHECK (agreed_minor >= 0),
  next_action   TEXT NOT NULL DEFAULT '' CHECK (length(next_action) <= 500),
  owner         TEXT NOT NULL DEFAULT '' CHECK (length(owner) <= 100),
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE mou_milestones (
  mou_id         INTEGER NOT NULL REFERENCES mous(id) ON DELETE CASCADE,
  seq            INTEGER NOT NULL CHECK (seq IN (1,2,3)),
  due_date       TEXT CHECK (due_date IS NULL OR due_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  docs_confirmed INTEGER CHECK (docs_confirmed IS NULL OR docs_confirmed IN (0,1)),
  PRIMARY KEY (mou_id, seq)
);

-- ---------- transactions (single source of truth for actuals) ---------
CREATE TABLE transactions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_type      TEXT NOT NULL CHECK (txn_type IN ('Income','Expenditure')),
  txn_date      TEXT CHECK (txn_date  IS NULL OR txn_date  GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'), -- received / invoice date
  grant_id      INTEGER NOT NULL REFERENCES grants(id)      ON DELETE RESTRICT,
  country_id    INTEGER NOT NULL REFERENCES countries(id)   ON DELETE RESTRICT,
  workstream_id INTEGER REFERENCES workstreams(id)          ON DELETE RESTRICT,
  category_id   INTEGER REFERENCES expense_categories(id)   ON DELETE RESTRICT,
  milestone     TEXT CHECK (milestone IS NULL OR milestone IN ('M1','M2','M3','N/A')),
  description   TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 500),
  staff_name    TEXT CHECK (staff_name IS NULL OR length(staff_name) <= 100),
  currency      TEXT NOT NULL REFERENCES currencies(code) ON DELETE RESTRICT,
  amount_minor  INTEGER NOT NULL CHECK (amount_minor >= 0),
  fx_rate       REAL CHECK (fx_rate IS NULL OR fx_rate > 0),   -- 1 unit of `currency` = fx_rate reporting-currency units
  status        TEXT NOT NULL CHECK (status IN ('Available','Outstanding','Paid')),
  due_date      TEXT CHECK (due_date     IS NULL OR due_date     GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  payment_date  TEXT CHECK (payment_date IS NULL OR payment_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  doc_ref       TEXT NOT NULL DEFAULT '' CHECK (length(doc_ref) <= 100),
  verified      INTEGER NOT NULL DEFAULT 0 CHECK (verified IN (0,1)),
  created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  -- income is always 'Available'; expenditure is 'Outstanding' or 'Paid'
  CHECK ((txn_type = 'Income' AND status = 'Available')
      OR (txn_type = 'Expenditure' AND status IN ('Outstanding','Paid')))
);
CREATE INDEX idx_txn_type_status ON transactions(txn_type, status);
CREATE INDEX idx_txn_grant       ON transactions(grant_id);
CREATE INDEX idx_txn_country     ON transactions(country_id);
CREATE INDEX idx_txn_workstream  ON transactions(workstream_id);
CREATE INDEX idx_txn_dates       ON transactions(txn_date, payment_date);
