'use strict';
const { bad } = require('./errors');

const isDate = (s) => {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s && +s.slice(0, 4) >= 1990 && +s.slice(0, 4) <= 2100;
};
const blank = (v) => v === '' || v == null;

/** Optional date -> 'YYYY-MM-DD' | null */
function date(v, field) {
  if (blank(v)) return null;
  if (!isDate(v)) throw bad(`${field}: must be a valid date (YYYY-MM-DD)`, field);
  return v;
}

/** Money (decimal number, max 2 dp, 0..1e12) -> integer cents. Blank -> 0 unless required. */
function money(v, field, { required = false } = {}) {
  if (blank(v)) { if (required) throw bad(`${field}: amount is required`, field); return 0; }
  const n = typeof v === 'string' ? Number(v.trim()) : v;
  if (typeof n !== 'number' || !Number.isFinite(n)) throw bad(`${field}: must be a number`, field);
  if (n < 0) throw bad(`${field}: cannot be negative`, field);
  if (n > 1e12) throw bad(`${field}: is too large`, field);
  const c = Math.round(n * 100);
  if (Math.abs(c / 100 - n) > 1e-9) throw bad(`${field}: use at most 2 decimal places`, field);
  return c;
}

function fx(v, field) {
  if (blank(v)) return null;
  const n = typeof v === 'string' ? Number(v.trim()) : v;
  if (typeof n !== 'number' || !Number.isFinite(n) || n <= 0 || n > 1e9) throw bad(`${field}: FX rate must be a positive number`, field);
  return n;
}

function text(v, field, { max = 500, required = false } = {}) {
  if (v == null) v = '';
  if (typeof v !== 'string') throw bad(`${field}: must be text`, field);
  const s = v.trim();
  if (required && !s) throw bad(`${field}: is required`, field);
  if (s.length > max) throw bad(`${field}: must be ${max} characters or fewer`, field);
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(s)) throw bad(`${field}: contains invalid characters`, field);
  return s;
}

function oneOf(v, allowed, field, { optional = false } = {}) {
  if (blank(v) && optional) return null;
  if (!allowed.includes(v)) throw bad(`${field}: must be one of ${allowed.join(', ')}`, field);
  return v;
}

function email(v, field) {
  const s = text(v, field, { max: 200 });
  if (s && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) throw bad(`${field}: not a valid email address`, field);
  return s;
}

function yesNo(v, field) {
  if (v === 'Yes' || v === 1 || v === true) return 1;
  if (v === 'No' || v === 0 || v === false) return 0;
  throw bad(`${field}: must be Yes or No`, field);
}

const requireObject = (b) => {
  if (!b || typeof b !== 'object' || Array.isArray(b)) throw bad('Request body must be a JSON object');
  return b;
};

module.exports = { isDate, blank, date, money, fx, text, oneOf, email, yesNo, requireObject };
