'use strict';
const path = require('node:path');
const express = require('express');
const Finance = require('../shared/finance');
const store = require('./store');
const auth = require('./auth');
const V = require('./validate');
const { ApiError, bad, notFound } = require('./errors');

const TZ = process.env.APP_TIMEZONE || 'Australia/Sydney';
const todayISO = () => new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const idParam = (req) => { const n = Number(req.params.id); if (!Number.isInteger(n) || n < 1) throw notFound('Record'); return n; };

function createApp(db, opts = {}) {
  const app = express();
  const throttle = auth.makeThrottle();
  const secureCookie = opts.secureCookie ?? process.env.NODE_ENV === 'production';
  app.disable('x-powered-by');
  app.set('trust proxy', opts.trustProxy ?? false);

  // ---- security headers -------------------------------------------------
  app.use((req, res, next) => {
    res.set({
      'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
      'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
    });
    if (req.path.startsWith('/api/')) res.set('Cache-Control', 'no-store');
    next();
  });

  app.use(express.json({ limit: '100kb' }));

  // ---- CSRF defence for state-changing requests ---------------------------
  app.use((req, _res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) return next(new ApiError(403, 'Cross-site request blocked')); } catch { return next(new ApiError(403, 'Bad origin')); } }
    if (Number(req.headers['content-length'] || 0) > 0 && !req.is('application/json')) return next(new ApiError(415, 'Content-Type must be application/json'));
    next();
  });

  app.use(auth.sessionMiddleware(db));

  const api = express.Router();
  const needUser = auth.requireRole('viewer'), needEditor = auth.requireRole('editor'), needAdmin = auth.requireRole('admin');
  const run = (fn) => store.tx(db, fn);

  api.get('/health', (_req, res) => { db.prepare('SELECT 1').get(); res.json({ ok: true }); });

  // ---- auth ---------------------------------------------------------------
  const DUMMY = auth.hashPassword('dummy-password-for-timing');
  api.post('/auth/login', (req, res) => {
    const { username, password } = V.requireObject(req.body);
    const key = String(username || '').toLowerCase() + '|' + req.ip;
    if (throttle.blocked(key)) throw new ApiError(429, 'Too many failed attempts. Try again in 15 minutes.');
    const u = typeof username === 'string' ? db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(username.trim()) : null;
    const ok = auth.verifyPassword(typeof password === 'string' ? password : '', u ? u.password_hash : DUMMY);
    if (!u || !ok) { throttle.fail(key); throw new ApiError(401, 'Incorrect username or password'); }
    throttle.reset(key);
    auth.cleanup(db);
    const s = auth.createSession(db, u.id);
    const secure = secureCookie || req.secure;
    res.set('Set-Cookie', `sid=${s.token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${s.maxAgeSec}${secure ? '; Secure' : ''}`);
    const user = { id: u.id, username: u.username, name: u.display_name || u.username, role: u.role };
    store.audit(db, user, 'user', u.id, 'login');
    res.json({ user });
  });
  api.post('/auth/logout', (req, res) => {
    if (req.user) store.audit(db, req.user, 'user', req.user.id, 'logout');
    auth.destroySession(db, req.sessionToken);
    res.set('Set-Cookie', 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
    res.json({ ok: true });
  });
  api.get('/auth/me', (req, res) => res.json({ user: req.user || null }));

  // ---- state & reports -----------------------------------------------------
  api.get('/state', needUser, (_req, res) => res.json(store.getState(db)));

  const reportInputs = (req) => {
    const S = store.getState(db);
    const gf = String(req.query.gf || '');
    if (gf && !S.L.grants.includes(gf)) throw bad('gf: unknown grant', 'gf');
    S.gf = gf;
    const mode = V.oneOf(req.query.mode || 'month', ['month', 'quarter', 'year'], 'mode');
    const fy = req.query.fy !== 'cal' && req.query.fy !== 'false';
    const today = req.query.today ? V.date(req.query.today, 'today') : todayISO();
    return { S, mode, fy, today };
  };
  api.get('/reports/summary', needUser, (req, res) => {
    const { S, mode, fy, today } = reportInputs(req);
    res.json({
      today, rep: S.rep, gf: S.gf,
      dashboard: Finance.dashboard(S, today), grants: Finance.grantSummary(S),
      countries: Finance.groupSummary(S, 'c', req.query.all === '1'), workstreams: Finance.groupSummary(S, 'w'),
      period: Finance.periodReport(S, mode, fy), reconciliation: Finance.reconciliation(S),
      mouSchedule: Finance.mouSchedule(S, today), followUps: Finance.followUps(S, today),
    });
  });
  api.get('/reports/period.csv', needUser, (req, res) => {
    const { S, mode, fy } = reportInputs(req);
    res.type('text/csv').set('Content-Disposition', `attachment; filename="report-${mode}.csv"`).send(Finance.periodCsv(Finance.periodReport(S, mode, fy)));
  });
  api.get('/export/transactions.csv', needUser, (_req, res) => {
    const S = store.getState(db);
    const head = ['id', 'date', 'type', 'grant', 'country', 'workstream', 'category', 'milestone', 'description', 'currency', 'amount', 'fx_rate', 'status', 'due_date', 'payment_date', 'doc_ref', 'verified', `amount_${S.rep}`];
    const rows = S.reg.map((r) => [r.id, r.date, r.type, r.g, r.c, r.w, r.cat, r.ms, r.d, r.ccy, r.amt, r.fx, r.st, r.due, r.pdate, r.doc, r.ver, Finance.RA(r, S.rep)]);
    res.type('text/csv').set('Content-Disposition', 'attachment; filename="transactions.csv"').send(Finance.toCsv([head, ...rows]));
  });

  // ---- generic CRUD helper ---------------------------------------------------
  function crud(base, entity, fns) {
    api.post(base, needEditor, (req, res) => {
      const out = run(() => { const r = fns.create(db, req.body, req.user); store.audit(db, req.user, entity, r.id, 'create', null, r); return r; });
      res.status(201).json(out);
    });
    api.patch(base + '/:id', needEditor, (req, res) => {
      const id = idParam(req);
      const out = run(() => { const r = fns.update(db, id, req.body); store.audit(db, req.user, entity, id, 'update', r.before, r.after); return r.after; });
      res.json(out);
    });
    api.delete(base + '/:id', needEditor, (req, res) => {
      const id = idParam(req);
      run(() => { const before = fns.remove(db, id); store.audit(db, req.user, entity, id, 'delete', before, null); });
      res.json({ ok: true });
    });
  }
  crud('/transactions', 'transaction', { create: store.createTxn, update: store.updateTxn, remove: store.deleteTxn });
  crud('/budget', 'budget_line', { create: store.createBud, update: store.updateBud, remove: store.deleteBud });
  crud('/mous', 'mou', { create: store.createMou, update: store.updateMou, remove: store.deleteMou });

  // ---- lookups & settings (admin) --------------------------------------------
  api.post('/lookups/:kind', needAdmin, (req, res) => {
    const name = run(() => { const n = store.addLookup(db, req.params.kind, V.requireObject(req.body).name); store.audit(db, req.user, 'lookup', req.params.kind, 'create', null, { name: n }); return n; });
    res.status(201).json({ name, list: store.names(db, req.params.kind) });
  });
  api.patch('/lookups/:kind', needAdmin, (req, res) => {
    const b = V.requireObject(req.body);
    const name = run(() => { const n = store.renameLookup(db, req.params.kind, b.name, b.newName); store.audit(db, req.user, 'lookup', req.params.kind, 'update', { name: b.name }, { name: n }); return n; });
    res.json({ name, list: store.names(db, req.params.kind) });
  });
  api.delete('/lookups/:kind', needAdmin, (req, res) => {
    const name = String(req.query.name || '');
    run(() => { store.deleteLookup(db, req.params.kind, name); store.audit(db, req.user, 'lookup', req.params.kind, 'delete', { name }, null); });
    res.json({ ok: true, list: store.names(db, req.params.kind) });
  });
  api.put('/settings', needAdmin, (req, res) => {
    const out = run(() => { const r = store.updateSettings(db, req.body); store.audit(db, req.user, 'setting', 'settings', 'update', r.before, r.settings); return r; });
    res.json({ settings: out.settings, warnings: out.warnings });
  });

  // ---- users & audit (admin) --------------------------------------------------
  api.get('/users', needAdmin, (_req, res) => res.json(store.listUsers(db)));
  api.post('/users', needAdmin, (req, res) => {
    const u = run(() => { const r = store.createUser(db, req.body); store.audit(db, req.user, 'user', r.id, 'create', null, r); return r; });
    res.status(201).json(u);
  });
  api.patch('/users/:id', needAdmin, (req, res) => {
    const id = idParam(req);
    const u = run(() => { const r = store.updateUser(db, id, req.body, req.user.id); store.audit(db, req.user, 'user', id, 'update', r.before, r.after); return r.after; });
    res.json(u);
  });
  api.get('/audit', needAdmin, (req, res) => res.json(store.listAudit(db, { limit: req.query.limit, entity: req.query.entity, entityId: req.query.entityId })));

  api.use((_req, _res, next) => next(notFound('Endpoint')));
  app.use('/api', api);

  // ---- static front-end ---------------------------------------------------------
  app.use('/shared', express.static(path.join(__dirname, '..', 'shared'), { index: false }));
  app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html' }));

  // ---- errors ---------------------------------------------------------------------
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, _next) => {
    if (err instanceof ApiError) return res.status(err.status).json({ error: { message: err.message, field: err.field } });
    if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: { message: 'Malformed JSON' } });
    if (err && err.type === 'entity.too.large') return res.status(413).json({ error: { message: 'Request too large' } });
    if (err && /constraint/i.test(String(err.message))) return res.status(422).json({ error: { message: 'The data violates a database rule: ' + String(err.message).replace(/^.*?:\s*/, '') } });
    console.error('Unhandled error:', err);
    res.status(500).json({ error: { message: 'Unexpected server error' } });
  });
  return app;
}

module.exports = { createApp, todayISO };
