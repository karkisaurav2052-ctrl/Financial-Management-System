'use strict';
// Usage: ADMIN_USER=alice ADMIN_PASSWORD='a-long-passphrase' npm run create-admin
const path = require('node:path');
const { open } = require('../server/db');
const store = require('../server/store');

const file = process.env.DB_FILE || path.join(__dirname, '..', 'data', 'gfms.sqlite');
const db = open(file);
const username = process.env.ADMIN_USER, password = process.env.ADMIN_PASSWORD;
if (!username || !password) { console.error('Set ADMIN_USER and ADMIN_PASSWORD (min 10 characters).'); process.exit(1); }
try {
  const u = store.createUser(db, { username, password, role: 'admin', name: process.env.ADMIN_NAME || username });
  console.log('Created administrator', u.username);
} catch (e) { console.error('Failed:', e.message); process.exit(1); }
