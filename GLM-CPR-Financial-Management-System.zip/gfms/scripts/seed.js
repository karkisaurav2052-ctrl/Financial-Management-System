'use strict';
// Usage: npm run seed [-- --demo]   (DB_FILE env var overrides the database path)
const path = require('node:path');
const { open } = require('../server/db');
const { seedOpening, seedDemo } = require('../server/seed');
const { todayISO } = require('../server/app');

const file = process.env.DB_FILE || path.join(__dirname, '..', 'data', 'gfms.sqlite');
const db = open(file);
seedOpening(db);
if (process.argv.includes('--demo')) seedDemo(db, todayISO());
console.log('Seeded', file, process.argv.includes('--demo') ? '(opening data + demo transactions)' : '(opening data)');
