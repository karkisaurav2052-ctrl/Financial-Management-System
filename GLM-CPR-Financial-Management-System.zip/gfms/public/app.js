(function () {
  'use strict';
  const F = window.Finance;

  // ---------------------------------------------------------------- state
  let S = null, ME = null, tab = 0, VC = null, VG = null, PD = null, NO = false, FU = [];
  let USERS = [], AUD = [], CFGWARN = [];
  const ADD = { inc: false, exp: false, mou: false, bud: false };
  const UIKEY = 'gfms_ui';
  let U = { gf: '', rp: 'month', fy: true, showAll: false };
  try { U = { ...U, ...JSON.parse(localStorage.getItem(UIKEY) || '{}') }; } catch (e) { /* private mode */ }
  const saveUI = () => { try { localStorage.setItem(UIKEY, JSON.stringify(U)); } catch (e) { /* ignore */ } };

  const TABS = ['Overview', 'MoU tracker', 'Country Financials', 'Grant Management', 'Workstream Financials', 'Financial Reporting', 'Transactions &amp; Reconciliation', 'System Configuration', 'Budget lines'];
  const FIN_TABS = [2, 3, 4, 8];
  const RESERVED = { works: ['Salary'], cats: ['Partner disbursement'] };

  // ---------------------------------------------------------------- helpers
  const $ = (s) => document.querySelector(s);
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const f2 = (n) => (+n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const cl = (n) => (n < -0.005 ? ' neg' : '');
  const pad = (n) => String(n).padStart(2, '0');
  const today = () => { const d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
  const isAdmin = () => ME && ME.role === 'admin';
  const canEdit = () => ME && ME.role !== 'viewer';
  const dis = () => (canEdit() ? '' : ' disabled');

  let noteTimer = null;
  function note(msg, kind) {
    const el = $('#sv');
    if (!el) return;
    el.textContent = msg || '';
    el.className = 'sv' + (kind === 'err' ? ' er' : kind === 'ok' ? ' ok' : '');
    clearTimeout(noteTimer);
    if (msg && kind !== 'err') noteTimer = setTimeout(() => { el.textContent = ''; }, 3500);
  }

  async function api(method, url, body) {
    const opt = { method, credentials: 'same-origin', headers: {} };
    if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    let r;
    try { r = await fetch(url, opt); } catch (e) { throw new Error('Cannot reach the server. Check your connection.'); }
    let j = null;
    try { j = await r.json(); } catch (e) { /* no body */ }
    if (r.status === 401 && !url.startsWith('/api/auth/login')) { ME = null; showLogin('Your session has ended. Please sign in again.'); throw Object.assign(new Error('Signed out'), { silent: true }); }
    if (!r.ok) throw Object.assign(new Error(j && j.error ? j.error.message : 'Request failed (' + r.status + ')'), { status: r.status, field: j && j.error && j.error.field });
    return j;
  }
  const fail = (e) => { if (!e.silent) note(e.message, 'err'); };

  async function load() {
    S = await api('GET', '/api/state');
    S.gf = U.gf && S.L.grants.includes(U.gf) ? U.gf : '';
    U.gf = S.gf;
  }

  // ---------------------------------------------------------------- small renderers
  const opt = (arr, v, blank) => (blank ? '<option value=""></option>' : '') + arr.map((x) => `<option${x === v ? ' selected' : ''}>${esc(x)}</option>`).join('');
  function ed(t, row, k, v, type, arr, cls, j) {
    const a = `data-t="${t}" data-id="${row.id}" data-k="${k}"${j != null ? ` data-j="${j}"` : ''}${dis()}`;
    if (arr) return `<select ${a}>${opt(arr, v, 1)}</select>`;
    return `<input ${a} type="${type || 'text'}" class="${cls || ''}" value="${esc(v)}"${type === 'number' ? ' step="any"' : ''}>`;
  }
  const tbl = (h, rows, nc) => `<div class="w"><table><tr>${h.map((x, j) => `<th class="${nc && nc.includes(j) ? 'n' : ''}">${x}</th>`).join('')}</tr>${rows}</table></div>`;
  const delBtn = (t, id) => `<td>${canEdit() ? `<button class="x" data-del="${t}:${id}" title="Delete row" aria-label="Delete row">${PD === t + ':' + id ? 'Confirm delete?' : '✕'}</button>` : ''}</td>`;
  function badge(s) {
    if (!s) return '';
    const c = { Paid: 'ok', Completed: 'ok', Overdue: 'bad', 'Due soon': 'wn', 'Awaiting deliverable': 'wn', 'Part-paid': 'wn', 'Approved - ready to pay': 'in' }[s] || 'mu';
    return `<span class="st ${c}">${esc(s)}</span>`;
  }
  const IC = {
    w: '<path d="M3 7h15a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7zm0 0V6a2 2 0 0 1 2-2h11M16 14h.01"/>', l: '<path d="M12 3 3 8l9 5 9-5-9-5zM3 13l9 5 9-5"/>',
    r: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3zM9 8h6M9 12h6"/>', c: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>', a: '<path d="M12 3 2 20h20L12 3zM12 10v4M12 17h.01"/>',
  };
  const EYE = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const K2 = (l, v) => `<div class="k"><span>${l}</span><b class="${v < -0.005 ? 'neg' : ''}">${f2(v)}</b></div>`;

  function util(p, b) {
    const pc = b > 0 ? (p / b) * 100 : 0;
    return `<div class="ut"><div class="uh"><b>Budget utilisation</b><span>${pc.toFixed(1)}% of allocated budget spent</span></div><div class="pb" role="progressbar" aria-valuenow="${pc.toFixed(1)}" aria-valuemin="0" aria-valuemax="100" aria-label="Budget utilisation"><i style="width:${Math.min(100, pc)}%"></i></div><div class="us"><span>Expenditure paid ${f2(p)}</span><span>Total allocated ${f2(b)} ${esc(S.rep)}</span></div></div>`;
  }
  const fbar = () => `<div class="fb"><label for="gf">By grants</label><select id="gf"><option value="">All grants</option>${S.L.grants.map((g) => `<option${S.gf === g ? ' selected' : ''}>${esc(g)}</option>`).join('')}</select>${S.gf ? `<span class="fchip">Showing ${esc(S.gf)} only</span>` : ''}</div>`;

  function hb(rows, ser) {
    const mx = Math.max(1, ...rows.flatMap((r) => ser.map((s) => r.v[s.k] || 0)));
    return ser.map((s) => `<span class="lg"><i style="background:${s.c}"></i>${esc(s.n)}</span>`).join('') + rows.map((r) => `<div class="cr"><div class="cl">${esc(r.l)}</div>${ser.map((s) => { const v = r.v[s.k] || 0; return `<div class="bw"><div><div class="bar" style="width:${Math.max(0, v) / mx * 100}%;background:${s.c}"></div></div><span>${f2(v)}</span></div>`; }).join('')}</div>`).join('');
  }

  // ---------------------------------------------------------------- forms for adding records
  function fld(key, label, type, o) {
    o = o || {};
    const cls = o.wide ? ' class="wide"' : '';
    if (o.opts) return `<label${cls}>${label}<select data-f="${key}">${opt(o.opts, o.val || '', o.blank !== false)}</select></label>`;
    return `<label${cls}>${label}<input data-f="${key}" type="${type || 'text'}"${type === 'number' ? ' step="any" min="0"' : ''} value="${esc(o.val || '')}"${o.ph ? ` placeholder="${esc(o.ph)}"` : ''}></label>`;
  }
  function addForm(kind) {
    if (!ADD[kind] || !canEdit()) return '';
    const L = S.L, g = S.gf || '';
    let title, fields;
    if (kind === 'inc') {
      title = 'Add income';
      fields = fld('date', 'Date received', 'date') + fld('g', 'Grant', 0, { opts: L.grants, val: g }) + fld('d', 'Description', 'text', { wide: true }) + fld('ccy', 'Currency', 0, { opts: L.ccys, val: S.rep, blank: false }) +
        fld('amt', 'Amount', 'number') + fld('fx', 'FX rate (if not ' + esc(S.rep) + ')', 'number') + fld('doc', 'Doc ref', 'text');
    } else if (kind === 'exp') {
      title = 'Add expenditure';
      fields = fld('date', 'Invoice date', 'date') + fld('g', 'Grant', 0, { opts: L.grants, val: g }) + fld('c', 'Country', 0, { opts: L.countries }) + fld('w', 'Workstream', 0, { opts: L.works }) + fld('cat', 'Category', 0, { opts: L.cats }) +
        fld('ms', 'Milestone', 0, { opts: ['M1', 'M2', 'M3', 'N/A'] }) + fld('d', 'Description', 'text', { wide: true }) + fld('staff', 'Staff (salary lines)', 'text') + fld('ccy', 'Currency', 0, { opts: L.ccys, val: S.rep, blank: false }) +
        fld('amt', 'Amount', 'number') + fld('fx', 'FX rate (if not ' + esc(S.rep) + ')', 'number') + fld('st', 'Status', 0, { opts: ['Outstanding', 'Paid'], val: 'Outstanding', blank: false }) +
        fld('due', 'Due date', 'date') + fld('pdate', 'Payment date', 'date') + fld('doc', 'Doc ref', 'text');
    } else if (kind === 'mou') {
      title = 'Add country MoU';
      const have = new Set(S.trk.map((t) => t.c));
      fields = fld('c', 'Country', 0, { opts: L.countries.slice(1).filter((c) => !have.has(c)) }) + fld('p', 'Partner institution', 'text') + fld('em', 'Partner email', 'text') + fld('g', 'Grant', 0, { opts: L.grants, val: g }) +
        fld('f', 'Agreed funding', 'number') + fld('s', 'MoU start', 'date') + fld('e', 'MoU end', 'date');
    } else {
      title = 'Add budget line';
      fields = fld('g', 'Grant', 0, { opts: L.grants, val: g }) + fld('c', 'Country', 0, { opts: L.countries }) + fld('w', 'Workstream', 0, { opts: L.works }) + fld('d', 'Description', 'text', { wide: true }) + fld('staff', 'Staff (salary lines)', 'text') + fld('a', 'Amount (' + esc(S.rep) + ')', 'number');
    }
    return `<div class="frm" data-kind="${kind}"><h3>${title}</h3><div class="fg">${fields}</div><div class="acts"><button class="bt" data-submit="${kind}">Save</button><button class="bt g" data-add="${kind}">Cancel</button><span class="ferr" role="alert"></span></div></div>`;
  }
  const addBtn = (kind, label) => (canEdit() ? `<button class="bt" data-add="${kind}">${ADD[kind] ? 'Close form' : label}</button>` : '');

  // ---------------------------------------------------------------- Overview
  function charts() {
    const A = [{ k: 'a', n: 'Total Available Funding', c: 'var(--c2)' }, { k: 'b', n: 'Total Budget Allocated', c: 'var(--c3)' }, { k: 'p', n: 'Actual Expenditure Paid', c: 'var(--ac)' }], BP = [A[1], A[2]];
    const g = S.L.grants.filter((x) => !S.gf || x === S.gf).map((x) => { const n = F.grantNums(S, x); return { l: x, v: { a: n.a, b: n.b, p: n.p } }; });
    const w = S.L.works.map((x) => ({ l: x, v: { b: F.budBy(S, 'w', x), p: F.paidBy(S, 'w', x) } })).filter((r) => r.v.b || r.v.p);
    const c = S.L.countries.slice(1).map((x) => ({ l: x, v: { b: F.budBy(S, 'c', x), p: F.paidBy(S, 'c', x) } })).filter((r) => r.v.b || r.v.p).sort((x, y) => y.v.b - x.v.b).slice(0, 12);
    return `<h2>Charts</h2><div class="g2"><div><b>Funding, budget and spending by grant</b>${hb(g, A)}</div><div><b>Budget and spending by workstream</b>${hb(w, BP)}</div><div><b>Budget and spending by country (top 12 by budget)</b>${hb(c, BP)}</div></div>`;
  }
  function followUps(T) {
    FU = F.followUps(S, T);
    const rows = FU.map((p, i) => {
      const sb = `Overdue milestone ${p.m} - ${p.c}`;
      const bd = `Dear ${p.p || p.c} team,\n\nOur records show that milestone ${p.m} for ${p.c} was due on ${p.d} and the deliverables have not yet been confirmed (${-p.n} days overdue). Please send the outstanding deliverables and supporting documents so that payment can be processed.\n\nKind regards,\nGLM-CPR Finance`;
      p.txt = sb + '\n\n' + bd;
      return `<tr class="al"><td>${esc(p.c)}</td><td>${p.m}</td><td>${p.d}</td><td class="n neg">${-p.n}</td><td>${p.em ? esc(p.em) : '<span class="note">no email on file</span>'}</td><td>${p.em ? `<a class="bt" href="mailto:${esc(p.em)}?subject=${encodeURIComponent(sb)}&body=${encodeURIComponent(bd)}">Notify</a>` : `<button class="bt g" data-nt="${i}">Copy message</button>`}</td></tr>`;
    }).join('');
    return '<h2>MoU follow-up: milestones not achieved on time</h2>' + (FU.length ? tbl(['Country', 'Milestone', 'Was due', 'Days late', 'Partner email', 'Notify'], rows, [3]) : '<p class="note">No overdue milestones. A milestone appears here when its due date has passed and “Docs confirmed” is not Yes.</p>');
  }
  function outstandingBlock(T) {
    const o = F.outstandingDue(S, T);
    return '<h2>Outstanding payments due within 28 days</h2>' + (o.rows.length
      ? tbl(['Country', 'Description', 'Amount', 'Due date', 'Days', 'Status'], o.rows.map((r) => `<tr class="al"><td>${esc(r.c)}</td><td>${esc(r.d)}</td><td class="n">${f2(r.amount)}</td><td>${esc(r.due)}</td><td class="n${r.n < 0 ? ' neg' : ''}">${r.n}</td><td>${badge(r.n < 0 ? 'Overdue' : 'Due soon')}</td></tr>`).join(''), [2, 4])
      : '<p class="note">No outstanding payments due within the next 28 days.</p>')
      + (o.noDue ? `<p class="note">${o.noDue} outstanding payment(s) have no due date. Add one in Transactions &amp; Reconciliation so they appear here 28 days ahead.</p>` : '');
  }
  function dash() {
    const T = today(), d = F.dashboard(S, T), P = F.upcomingPayments(S, T);
    const K = (l, v, c, ic) => `<div class="k${c || ''}"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[ic] || ''}</svg><span>${l}</span><b class="${v < -0.005 ? 'neg' : ''}">${f2(v)}</b></div>`;
    let h = `<h2>Funds and spending (${esc(S.rep)})${S.gf ? ' - ' + esc(S.gf) : ''}</h2><div class="kp">${K('Total Available Funding', d.available, ' c-teal', 'w')}${K('Total Budget Allocated', d.budget, ' c-blue', 'l')}${K('Actual Expenditure Paid', d.paid, ' c-green', 'r')}${K('Budget Remaining', d.remaining, ' c-violet', 'c')}${K('Budget Surplus / (Deficit)', d.surplus, d.surplus < 0 ? ' bad' : ' c-gold', d.surplus < 0 ? 'a' : 'c')}</div>
 <p class="note">Budget Remaining = Total Budget Allocated − Actual Expenditure Paid. Budget Surplus / (Deficit) = Total Available Funding − Total Budget Allocated (negative = deficit).</p>${util(d.paid, d.budget)}${charts()}
 <h2>Upcoming MoU payments</h2><div class="kp"><div class="k"><span>Overdue</span><b class="${d.overdue.n ? 'neg' : ''}">${d.overdue.n} · ${f2(d.overdue.amount)}</b></div><div class="k"><span>Due in next 28 days</span><b>${d.next28.n} · ${f2(d.next28.amount)}</b></div><div class="k"><span>Outstanding under MoUs</span><b>${f2(d.mouOutstanding)}</b></div></div><br>`;
    h += P.length ? tbl(['Country', 'Milestone', 'Amount', 'Due', 'Days', 'Status'], P.slice(0, 10).map((p) => `<tr class="${p.n <= 28 ? 'al' : ''}"><td>${esc(p.c)}</td><td>${p.m}</td><td class="n">${f2(p.a)}</td><td>${p.d}</td><td class="n${p.n < 0 ? ' neg' : ''}">${p.n}</td><td>${badge(p.s)}</td></tr>`).join(''), [2, 4]) : '<p class="note">No payments scheduled. Add due dates in the MoU tracker.</p>';
    h += followUps(T) + outstandingBlock(T);
    h += '<h2>MoU payment schedule</h2>' + tbl(['Partner / Country', 'MoU Total Value', 'Amount Paid', 'Outstanding Amount', 'Next Due Date', 'Payment Status'],
      F.mouSchedule(S, T).map((x) => `<tr><td>${esc(x.p ? x.p + ' – ' : '')}${esc(x.c)}</td><td class="n">${f2(x.total)}</td><td class="n">${f2(x.paid)}</td><td class="n">${f2(x.outstanding)}</td><td>${esc(x.next)}</td><td>${badge(x.status)}</td></tr>`).join(''), [1, 2, 3]);
    h += '<h2>By grant</h2>' + tbl(['Grant', 'Total Available Funding', 'Total Budget Allocated', 'Actual Expenditure Paid', 'Budget Remaining', 'Budget Surplus / (Deficit)'],
      S.L.grants.filter((g) => !S.gf || g === S.gf).map((g) => { const n = F.grantNums(S, g); return `<tr><td>${esc(g)}</td><td class="n">${f2(n.a)}</td><td class="n">${f2(n.b)}</td><td class="n">${f2(n.p)}</td><td class="n${cl(n.b - n.p)}">${f2(n.b - n.p)}</td><td class="n${cl(n.surplus)}">${f2(n.surplus)}</td></tr>`; }).join(''), [1, 2, 3, 4, 5]);
    const rc = F.reconciliation(S);
    const C = (c) => `<tr><td>${esc(c.label)}</td><td class="${c.ok ? 'ok' : 'neg'}">${c.ok ? 'OK' : 'Check'}</td><td>${esc(typeof c.detail === 'number' ? f2(c.detail) : c.detail)}</td></tr>`;
    h += '<h2>Reconciliation checks</h2>' + tbl(['Check', 'Status', 'Detail'], rc.checks.map(C).join('')
      + `<tr><td>Transaction rows not yet verified</td><td class="${rc.unverified.n ? 'wn' : 'ok'}">${rc.unverified.n ? 'Verify' : 'OK'}</td><td>${rc.unverified.n} of ${rc.unverified.of}</td></tr>`
      + `<tr><td>Paid per CPA statement</td><td colspan="2"><input type="number" step="any" id="cpa" value="${S.cpa == null ? '' : esc(S.cpa)}" placeholder="enter CPA total"${isAdmin() ? '' : ' disabled'}> <span class="note">${rc.cpa ? (rc.cpa.ok ? '<b class="ok">OK</b>' : '<b class="neg">Difference ' + f2(rc.cpa.diff) + '</b>') : ''}</span></td></tr>`);
    return h;
  }

  // ---------------------------------------------------------------- MoU tracker
  function trk() {
    const T = today();
    const rows = S.trk.map((t) => {
      if (S.gf && t.g !== S.gf) return '';
      let ms = '', al = false;
      for (let k = 0; k < 3; k++) {
        const a = F.milestoneAmountC(S, t, k) / 100, s = F.milestoneStatus(S, t, k, T);
        if (t.due[k] && s && s !== 'Paid' && F.dd(t.due[k], T) <= 28) al = true;
        ms += `<td class="n">${a ? f2(a) : ''}</td><td><input type="date" data-t="trk" data-id="${t.id}" data-k="due" data-j="${k}" value="${esc(t.due[k])}"${dis()}></td><td><select data-t="trk" data-id="${t.id}" data-k="conf" data-j="${k}"${dis()}>${opt(['Yes', 'No'], t.conf[k], 1)}</select></td><td>${badge(s)}</td><td class="n">${f2(F.disbursed(S, t.c, k))}</td>`;
      }
      const tp = F.disbursed(S, t.c), nm = tp - F.disbursed(S, t.c, 0) - F.disbursed(S, t.c, 1) - F.disbursed(S, t.c, 2);
      return `<tr class="${al ? 'al' : ''}"><td>${ed('trk', t, 'c', t.c, 0, S.L.countries.slice(1))}</td><td>${ed('trk', t, 'p', t.p, 0, 0, 'l')}</td><td>${ed('trk', t, 'em', t.em, 0, 0, 'l')}</td><td>${ed('trk', t, 'g', t.g, 0, S.L.grants)}</td><td>${ed('trk', t, 's', t.s, 'date')}</td><td>${ed('trk', t, 'e', t.e, 'date')}</td><td>${ed('trk', t, 'f', t.f, 'number')}</td>${ms}<td class="n">${f2(tp)}</td><td class="n">${f2(nm)}</td><td class="n">${f2((+t.f || 0) - tp)}</td><td>${ed('trk', t, 'act', t.act, 0, 0, 'l')}</td><td>${ed('trk', t, 'who', t.who, 0, 0, 's')}</td>${delBtn('trk', t.id)}</tr>`;
    }).join('');
    const mh = ['Amount', 'Due', 'Docs confirmed?', 'Status', 'Paid'];
    return `<h2>MoU and payment tracker</h2>${addBtn('mou', 'Add country row')}${addForm('mou')}
 <p class="note">Payments are released by milestone. Set “Docs confirmed” to Yes only after the deliverables are signed off. Paid amounts come from Transactions &amp; Reconciliation (category Partner disbursement, status Paid, milestone M1–M3). Highlighted rows have a payment due within 4 weeks or overdue.</p>`
      + tbl(['Country', 'Partner institution', 'Partner email', 'Grant', 'MoU start', 'MoU end', 'Agreed funding', ...mh.map((x) => 'M1 ' + x), ...mh.map((x) => 'M2 ' + x), ...mh.map((x) => 'M3 ' + x), 'Total paid', 'Paid, no milestone', 'Outstanding', 'Next action', 'Who', ''], rows, [6, 7, 11, 12, 16, 17, 21, 22, 23, 24]);
  }

  // ---------------------------------------------------------------- Country / Workstream / Grant
  function sm(key) {
    const name = key === 'c' ? 'Country' : 'Workstream';
    const r = F.groupSummary(S, key, U.showAll);
    const line = (x, sub) => `<tr><td${sub ? ' style="padding-left:26px;color:var(--mu)"' : ''}>${esc(x.name)}${!sub && key === 'c' && x.name !== S.L.countries[0] ? `<button class="vw" data-view="${esc(x.name)}" title="View expenditure in ${esc(x.name)}" aria-label="View expenditure in ${esc(x.name)}">${EYE}</button>` : ''}</td><td class="n">${f2(x.b)}</td><td class="n">${f2(x.p)}</td><td class="n">${f2(x.c)}</td><td class="n${cl(x.rem)}">${f2(x.rem)}</td><td class="n">${x.pct == null ? '' : x.pct + '%'}</td></tr>`;
    const rows = r.rows.map((x) => line(x) + (x.sub ? x.sub.map((s) => line({ name: s.name, b: s.b, p: s.p, c: s.c, rem: s.rem, pct: s.pct }, true)).join('') : '')).join('')
      + `<tr class="t"><td>Total</td><td class="n">${f2(r.total.b)}</td><td class="n">${f2(r.total.p)}</td><td class="n">${f2(r.total.c)}</td><td class="n">${f2(r.total.rem)}</td><td class="n">${r.total.pct == null ? '' : r.total.pct + '%'}</td></tr>`;
    return `<h2>${name} Financials</h2>${key === 'c' ? `<button class="bt g" id="sall">${U.showAll ? 'Hide countries with no activity' : 'Show all ' + (S.L.countries.length - 1) + ' countries'}</button>` : ''}<p class="note">Calculated from Transactions &amp; Reconciliation and the budget lines.</p><div class="eq">${tbl([name, 'Budget', 'Paid', 'Outstanding', 'Remaining after outstandings', '% used'], rows, [1, 2, 3, 4, 5])}</div>`;
  }
  function cdet() {
    const c = VC, d = F.detail(S, 'c', c), wr = F.breakdown(S, 'c', c, 'w');
    const tx = F.regF(S).filter((r) => r.c === c && r.type === 'Expenditure').map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.d)}</td><td>${esc(r.w)}</td><td>${esc(r.cat)}</td><td>${esc(r.ms)}</td><td class="n">${f2(F.RA(r, S.rep))}</td><td>${badge(r.st)}</td><td>${esc(r.pdate)}</td><td>${esc(r.doc)}</td></tr>`).join('');
    return `<button class="bt g" id="vback">&larr; Back to all countries</button><h2>${esc(c)}: expenditure by heading</h2><div class="kp">${K2('Budget', d.b)}${K2('Paid', d.p)}${K2('Outstanding', d.o)}${K2('Remaining after outstandings', d.remaining)}</div><h2>By workstream heading</h2>`
      + (wr.length ? tbl(['Workstream', 'Budget', 'Paid', 'Outstanding', 'Remaining'], wr.map((x) => `<tr><td>${esc(x.name)}</td><td class="n">${f2(x.b)}</td><td class="n">${f2(x.p)}</td><td class="n">${f2(x.o)}</td><td class="n${cl(x.rem)}">${f2(x.rem)}</td></tr>`).join(''), [1, 2, 3, 4]) : '<p class="note">No budget or expenditure recorded for this country yet.</p>')
      + '<h2>Expenditure transactions</h2>' + (tx ? tbl(['Invoice date', 'Description', 'Workstream', 'Category', 'Milestone', 'Amount (' + esc(S.rep) + ')', 'Status', 'Payment date', 'Doc ref'], tx, [5]) : '<p class="note">No expenditure has been recorded for this country yet.</p>');
  }
  function gsum() {
    const r = F.grantSummary(S);
    const line = (n, label, t) => `<tr${t ? ' class="t"' : ''}><td>${label}${t ? '' : `<button class="vw" data-gview="${esc(n.g)}" title="View ${esc(n.g)}" aria-label="View ${esc(n.g)}">${EYE}</button>`}</td><td class="n">${f2(n.a)}</td><td class="n">${f2(n.b)}</td><td class="n">${f2(n.p)}</td><td class="n">${f2(n.o)}</td><td class="n${cl(n.remaining)}">${f2(n.remaining)}</td><td class="n${cl(n.surplus)}">${f2(n.surplus)}</td></tr>`;
    return '<h2>Grant Management</h2><p class="note">Funding, budget and spending for each grant. Select the eye icon to see one grant in detail, or to filter the Overview, MoU tracker and Country Financials by that grant.</p><div class="eq g7">'
      + tbl(['Grant', 'Total Available Funding', 'Total Budget Allocated', 'Actual Expenditure Paid', 'Outstanding', 'Budget Remaining after outstandings', 'Budget Surplus / (Deficit)'], r.rows.map((n) => line(n, esc(n.g))).join('') + line(r.total, 'Total', true), [1, 2, 3, 4, 5, 6]) + '</div>';
  }
  function gdet() {
    const g = VG, n = F.grantNums(S, g), S0 = { ...S, gf: '' };
    const cr = F.breakdown(S0, 'g', g, 'c'), wr = F.breakdown(S0, 'g', g, 'w');
    const hd = ['Budget', 'Paid', 'Outstanding', 'Remaining'];
    const rows = (L) => L.map((x) => `<tr><td>${esc(x.name)}</td><td class="n">${f2(x.b)}</td><td class="n">${f2(x.p)}</td><td class="n">${f2(x.o)}</td><td class="n${cl(x.rem)}">${f2(x.rem)}</td></tr>`).join('');
    const ir = S.reg.filter((r) => r.g === g && r.type === 'Income').map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.d)}</td><td class="n">${f2(F.RA(r, S.rep))}</td><td>${esc(r.doc)}</td></tr>`).join('');
    const er = S.reg.filter((r) => r.g === g && r.type === 'Expenditure').map((r) => `<tr><td>${esc(r.date)}</td><td>${esc(r.c)}</td><td>${esc(r.d)}</td><td>${esc(r.w)}</td><td>${esc(r.cat)}</td><td class="n">${f2(F.RA(r, S.rep))}</td><td>${badge(r.st)}</td><td>${esc(r.pdate)}</td><td>${esc(r.doc)}</td></tr>`).join('');
    return `<button class="bt g" id="gback">&larr; Back to all grants</button><button class="bt" data-gfilter="${esc(g)}">Filter Overview, MoU tracker and Country Financials by ${esc(g)}</button><h2>${esc(g)}: funding and spending</h2><div class="kp">${K2('Total Available Funding', n.a)}${K2('Total Budget Allocated', n.b)}${K2('Actual Expenditure Paid', n.p)}${K2('Outstanding', n.o)}${K2('Budget Surplus / (Deficit)', n.surplus)}</div>`
      + '<h2>By country</h2>' + (cr.length ? tbl(['Country', ...hd], rows(cr), [1, 2, 3, 4]) : '<p class="note">No budget or expenditure for this grant yet.</p>')
      + '<h2>By workstream heading</h2>' + (wr.length ? tbl(['Workstream', ...hd], rows(wr), [1, 2, 3, 4]) : '<p class="note">None yet.</p>')
      + '<h2>Income</h2>' + (ir ? tbl(['Date received', 'Description', 'Amount (' + esc(S.rep) + ')', 'Doc ref'], ir, [2]) : '<p class="note">No income recorded for this grant.</p>')
      + '<h2>Expenditure transactions</h2>' + (er ? tbl(['Invoice date', 'Country', 'Description', 'Workstream', 'Category', 'Amount (' + esc(S.rep) + ')', 'Status', 'Payment date', 'Doc ref'], er, [5]) : '<p class="note">No expenditure recorded for this grant.</p>');
  }

  // ---------------------------------------------------------------- Reporting
  const csvQ = () => `mode=${U.rp}&fy=${U.fy ? 'fy' : 'cal'}&gf=${encodeURIComponent(S.gf)}`;
  function rpt() {
    const r = F.periodReport(S, U.rp, U.fy);
    const rows = r.rows.map((x) => `<tr><td>${esc(x.label)}</td><td class="n">${f2(x.income)}</td><td class="n">${f2(x.paid)}</td><td class="n">${f2(x.outstanding)}</td><td class="n${cl(x.net)}">${f2(x.net)}</td><td class="n${cl(x.cumulative)}">${f2(x.cumulative)}</td></tr>`).join('')
      + `<tr class="t"><td>Total</td><td class="n">${f2(r.total.income)}</td><td class="n">${f2(r.total.paid)}</td><td class="n">${f2(r.total.outstanding)}</td><td class="n${cl(r.total.net)}">${f2(r.total.net)}</td><td class="n">${f2(r.total.cumulative)}</td></tr>`;
    const wrows = r.matrix.map((m) => `<tr><td>${esc(m.workstream)}</td>${m.cells.map((v) => `<td class="n">${v ? f2(v) : '-'}</td>`).join('')}<td class="n"><b>${f2(m.total)}</b></td></tr>`).join('')
      + `<tr class="t"><td>Total paid</td>${r.matrixTotals.map((v) => `<td class="n">${f2(v)}</td>`).join('')}<td class="n">${f2(r.total.paid)}</td></tr>`;
    const seg = [['month', 'Monthly'], ['quarter', 'Quarterly'], ['year', 'Yearly']].map(([k, l]) => `<button data-rp="${k}" class="${U.rp === k ? 'on' : ''}" aria-pressed="${U.rp === k}">${l}</button>`).join('');
    const ch = hb(r.rows.map((x) => ({ l: x.label, v: { i: x.income, p: x.paid } })), [{ k: 'i', n: 'Income', c: 'var(--c2)' }, { k: 'p', n: 'Expenditure paid', c: 'var(--ac)' }]);
    const title = U.rp === 'month' ? 'Monthly' : U.rp === 'quarter' ? 'Quarterly' : 'Yearly';
    return `<div class="top"><div><h2>Financial Reporting</h2><p class="note">Income is counted on its date received, paid expenditure on its payment date (or invoice date if no payment date), and outstanding on its invoice date. Records with no date appear as Undated. The grant filter above applies.</p></div><div><a class="bt g" href="/api/reports/period.csv?${csvQ()}" download>Download CSV</a></div></div>
 <div class="rc"><div class="seg" role="group" aria-label="Report period">${seg}</div><label for="rfy">Year basis</label><select id="rfy"><option value="fy"${U.fy ? ' selected' : ''}>Financial year (Jul to Jun)</option><option value="cal"${U.fy ? '' : ' selected'}>Calendar year</option></select></div>
 <section class="card"><div class="ch2"><h2>${title} summary (${esc(S.rep)})</h2></div>${r.rows.length ? tbl(['Period', 'Income', 'Expenditure paid', 'Outstanding invoiced', 'Net (income less paid)', 'Cumulative net'], rows, [1, 2, 3, 4, 5]) : '<p class="note" style="padding:16px">No dated transactions yet.</p>'}</section>
 <section class="card"><div class="ch2"><h2>Chart</h2></div><div style="padding:14px 18px">${r.rows.length ? ch : '<p class="note">Nothing to chart yet.</p>'}</div></section>
 <section class="card"><div class="ch2"><h2>Paid expenditure by workstream</h2></div>${r.matrix.length ? tbl(['Workstream', ...r.labels.map(esc), 'Total'], wrows, r.keys.map((_, i) => i + 1).concat([r.keys.length + 1])) : '<p class="note" style="padding:16px">No paid expenditure yet.</p>'}</section>`;
  }

  // ---------------------------------------------------------------- Transactions
  function acct() {
    const R = (ty) => S.reg.filter((r) => r.type === ty);
    const sum = (ty, st) => F.fromC(R(ty).filter((r) => !st || r.st === st).reduce((a, r) => a + F.rowC(r, S.rep), 0));
    const e = (t, r, k, v, ty, a, c) => `<td>${ed(t, r, k, v, ty, a, c)}</td>`;
    const inc = R('Income').map((r) => `<tr>${e('reg', r, 'date', r.date, 'date')}${e('reg', r, 'g', r.g, 0, S.L.grants)}${e('reg', r, 'd', r.d, 0, 0, 'l')}${e('reg', r, 'ccy', r.ccy, 0, S.L.ccys)}${e('reg', r, 'amt', r.amt, 'number')}${e('reg', r, 'fx', r.fx, 'number', 0, 's')}<td class="n">${f2(F.RA(r, S.rep))}</td>${e('reg', r, 'doc', r.doc, 0, 0, 's')}${e('reg', r, 'ver', r.ver, 0, ['Yes', 'No'])}${delBtn('reg', r.id)}</tr>`).join('');
    const exp = R('Expenditure').map((r) => `<tr>${e('reg', r, 'date', r.date, 'date')}${e('reg', r, 'g', r.g, 0, S.L.grants)}${e('reg', r, 'c', r.c, 0, S.L.countries)}${e('reg', r, 'w', r.w, 0, S.L.works)}${e('reg', r, 'cat', r.cat, 0, S.L.cats)}${e('reg', r, 'ms', r.ms, 0, ['M1', 'M2', 'M3', 'N/A'])}${e('reg', r, 'd', r.d, 0, 0, 'l')}${e('reg', r, 'staff', r.staff, 0, 0, 's')}${e('reg', r, 'ccy', r.ccy, 0, S.L.ccys)}${e('reg', r, 'amt', r.amt, 'number')}${e('reg', r, 'fx', r.fx, 'number', 0, 's')}<td class="n">${f2(F.RA(r, S.rep))}</td>${e('reg', r, 'st', r.st, 0, ['Outstanding', 'Paid'])}${e('reg', r, 'due', r.due, 'date')}${e('reg', r, 'pdate', r.pdate, 'date')}${e('reg', r, 'doc', r.doc, 0, 0, 's')}${e('reg', r, 'ver', r.ver, 0, ['Yes', 'No'])}${delBtn('reg', r.id)}</tr>`).join('');
    return `<div class="top"><div><h2>Transactions &amp; Reconciliation</h2><p class="note">Income and expenditure are recorded once here. Every dashboard, chart and summary updates from these rows. Amount (${esc(S.rep)}) = amount, or amount × FX rate for other currencies. Invoice date = when the invoice was raised. Payment date = when the payment cleared. Every change is saved to the server immediately and recorded in the audit log.</p></div><div><a class="bt g" href="/api/export/transactions.csv" download>Download CSV</a></div></div>
 ${addForm('inc')}${addForm('exp')}
 <section class="card"><div class="ch2"><h2>Income</h2><span class="tt">Total ${f2(sum('Income'))} ${esc(S.rep)}</span>${addBtn('inc', 'Add income')}</div>${tbl(['Date received', 'Grant', 'Description', 'Ccy', 'Amount', 'FX rate', 'Amount (' + esc(S.rep) + ')', 'Doc ref', 'Verified', ''], inc, [4, 5, 6])}</section>
 <section class="card"><div class="ch2"><h2>Expenditure</h2><span class="tt">Paid ${f2(sum('Expenditure', 'Paid'))} · Outstanding ${f2(sum('Expenditure', 'Outstanding'))} ${esc(S.rep)}</span>${addBtn('exp', 'Add expenditure')}</div>${tbl(['Invoice date', 'Grant', 'Country', 'Workstream', 'Category', 'Milestone', 'Description', 'Staff', 'Ccy', 'Amount', 'FX rate', 'Amount (' + esc(S.rep) + ')', 'Status', 'Due date', 'Payment date', 'Doc ref', 'Verified', ''], exp, [9, 10, 11])}</section>`;
  }

  // ---------------------------------------------------------------- Budget lines
  function bud() {
    const L = F.budF(S);
    const e = (r, k, v, ty, a, c) => `<td>${ed('bud', r, k, v, ty, a, c)}</td>`;
    const rows = L.map((r) => `<tr>${e(r, 'g', r.g, 0, S.L.grants)}${e(r, 'c', r.c, 0, S.L.countries)}${e(r, 'w', r.w, 0, S.L.works)}${e(r, 'd', r.d, 0, 0, 'l')}${e(r, 'staff', r.staff, 0, 0, 's')}${e(r, 'a', r.a, 'number')}${delBtn('bud', r.id)}</tr>`).join('')
      + `<tr class="t"><td>Total</td><td></td><td></td><td></td><td></td><td class="n">${f2(F.totalBudget(S))}</td><td></td></tr>`;
    return `<h2>Budget lines</h2>${addBtn('bud', 'Add budget line')}${addForm('bud')}<p class="note">The budget by grant, country and workstream. All “Budget” columns in the dashboards come from these lines (amounts in ${esc(S.rep)}). Tag salary lines with a staff name to see the per-person salary breakdown in Workstream Financials.</p>${tbl(['Grant', 'Country', 'Workstream', 'Description', 'Staff', 'Amount (' + esc(S.rep) + ')', ''], rows, [5])}`;
  }

  // ---------------------------------------------------------------- System configuration
  const diff = (b, a) => {
    if (!b && a) return Object.entries(a).filter(([k, v]) => v !== '' && v != null && k !== 'id').slice(0, 8).map(([k, v]) => `${k}: ${v}`).join(', ');
    if (b && !a) return Object.entries(b).filter(([k, v]) => v !== '' && v != null && k !== 'id').slice(0, 8).map(([k, v]) => `${k}: ${v}`).join(', ');
    return Object.keys(a || {}).filter((k) => JSON.stringify(a[k]) !== JSON.stringify(b[k])).map((k) => `${k}: ${JSON.stringify(b[k])} → ${JSON.stringify(a[k])}`).join('; ');
  };
  function lkCard(kind, label, items) {
    const rows = items.map((n, i) => {
      const lock = (RESERVED[kind] || []).includes(n) || (kind === 'countries' && i === 0) || (kind === 'ccys' && n === S.rep);
      return `<div class="lki"><input data-lk="${kind}" data-old="${esc(n)}" value="${esc(n)}" aria-label="Rename ${esc(n)}"${lock || kind === 'ccys' ? ' disabled' : ''}><button class="x" data-lkdel="${kind}" data-name="${esc(n)}" aria-label="Remove ${esc(n)}"${lock ? ' disabled' : ''}>✕</button>${lock ? '<span class="lock">system</span>' : ''}</div>`;
    }).join('');
    return `<div><b>${label}</b><div class="lkl">${rows}</div><div class="lkadd"><input id="lkn-${kind}" placeholder="Add ${label.toLowerCase()}" aria-label="New ${label.toLowerCase()}"><button class="bt" data-lkadd="${kind}">Add</button></div></div>`;
  }
  function cfg() {
    if (!isAdmin()) return `<h2>System Configuration</h2><p class="note">Only administrators can change configuration. Reporting currency: <b>${esc(S.rep)}</b>. Milestone shares: ${S.pct.map((p, i) => `M${i + 1} ${Math.round(p * 100)}%`).join(', ')}.</p>`;
    const warn = CFGWARN.map((w) => `<div class="warn" role="alert">${esc(w)}</div>`).join('');
    const users = USERS.map((u) => `<tr><td>${esc(u.username)}</td><td>${esc(u.name)}</td><td><select data-urole="${u.id}"${u.id === ME.id ? ' disabled' : ''}>${opt(['admin', 'editor', 'viewer'], u.role)}</select></td><td><select data-uact="${u.id}"${u.id === ME.id ? ' disabled' : ''}><option value="1"${u.active ? ' selected' : ''}>Active</option><option value="0"${u.active ? '' : ' selected'}>Inactive</option></select></td><td><button class="bt g" data-upw="${u.id}">Set password</button></td></tr>`).join('');
    const aud = AUD.slice(0, 100).map((a) => `<tr><td>${esc(a.ts.replace('T', ' ').slice(0, 19))}</td><td>${esc(a.user || 'system')}</td><td>${esc(a.action)}</td><td>${esc(a.entity)} ${esc(a.entityId)}</td><td class="pre">${esc(diff(a.before, a.after))}</td></tr>`).join('');
    return `<h2>System Configuration</h2>${warn}<p class="note">Renaming an item updates every record that uses it. Items in use cannot be removed. Items marked “system” are required by the calculations.</p>
 <div class="g3">${lkCard('grants', 'Grants', S.L.grants)}${lkCard('countries', 'Countries (first is the non-country bucket)', S.L.countries)}${lkCard('works', 'Workstreams', S.L.works)}${lkCard('cats', 'Expense categories', S.L.cats)}${lkCard('ccys', 'Currencies', S.L.ccys)}</div>
 <h2>Reporting currency and milestone shares</h2><p><label for="rep">Reporting currency</label> <select id="rep">${opt(S.L.ccys, S.rep)}</select> <span class="note">Record the rate used on each foreign-currency row.</span></p>
 <p>${[0, 1, 2].map((k) => `M${k + 1} share <input type="number" class="s" data-pct="${k}" value="${Math.round(S.pct[k] * 100)}" min="0" max="100" aria-label="M${k + 1} share percent">%`).join(' &nbsp; ')} <span class="note">30/30/40 is a placeholder until the real milestone split is confirmed.</span></p>
 <h2>Users</h2><div class="frm"><div class="fg">${fld('username', 'Username', 'text')}${fld('name', 'Display name', 'text')}${fld('role', 'Role', 0, { opts: ['viewer', 'editor', 'admin'], val: 'viewer', blank: false })}<label>Password (10+ characters)<input data-f="password" type="password" autocomplete="new-password"></label></div><div class="acts"><button class="bt" data-uadd="1">Add user</button><span class="ferr" role="alert"></span></div></div>
 ${tbl(['Username', 'Name', 'Role', 'Status', ''], users)}
 <h2>Audit log (latest 100)</h2><div class="act"><button class="bt g" id="audref">Refresh</button></div>${AUD.length ? tbl(['Time (UTC)', 'User', 'Action', 'Record', 'Change'], aud) : '<p class="note">No entries.</p>'}`;
  }

  // ---------------------------------------------------------------- login / chrome
  function showLogin(msg) {
    $('#nav').innerHTML = ''; $('#who').innerHTML = ''; $('#sub').textContent = '';
    $('#m').innerHTML = `<div class="login"><div class="card"><h2>Sign in</h2><label for="lu">Username</label><input id="lu" autocomplete="username" autocapitalize="off"><label for="lp">Password</label><input id="lp" type="password" autocomplete="current-password"><button class="bt" id="login">Sign in</button><div class="err" id="lerr" role="alert">${esc(msg || '')}</div></div></div>`;
    const u = $('#lu'); if (u) u.focus();
  }
  function drawNav() {
    const b = (i) => `<button class="${i === tab ? 'on' : ''}" data-tab="${i}"${i === tab ? ' aria-current="page"' : ''}>${TABS[i]}</button>`, act = FIN_TABS.includes(tab);
    $('#nav').innerHTML = b(0) + b(1) + `<div class="ng"><button class="${act ? 'on' : ''}" data-ng="1" aria-haspopup="true" aria-expanded="${NO}">${act ? TABS[tab] : 'Financials'} <svg viewBox="0 0 12 12" width="10" height="10" aria-hidden="true"><path d="M2 4l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>${NO ? `<div class="ngm" role="menu">${FIN_TABS.map((i) => `<button role="menuitem" class="${i === tab ? 'on' : ''}" data-tab="${i}">${TABS[i]}</button>`).join('')}</div>` : ''}</div>` + b(5) + b(6) + b(7);
  }
  function draw() {
    if (!ME || !S) return;
    drawNav();
    $('#sub').innerHTML = 'Reporting currency <b>' + esc(S.rep) + '</b>. As at ' + new Date().toLocaleDateString('en-AU', { day: 'numeric', month: 'short', year: 'numeric' }) + '.';
    $('#who').innerHTML = `<span><b>${esc(ME.name)}</b> <span class="rolebadge">${esc(ME.role)}</span></span><button class="bt g" id="logout">Sign out</button>`;
    const showF = [0, 1, 2, 4, 5, 8].includes(tab) && !(tab === 2 && VC);
    const views = [dash, trk, () => (VC ? cdet() : sm('c')), () => (VG ? gdet() : gsum()), () => sm('w'), rpt, acct, cfg, bud];
    $('#m').innerHTML = (showF ? fbar() : '') + views[tab]();
  }
  async function goTab(i) {
    tab = i; VC = null; VG = null; PD = null; NO = false;
    if (i === 7 && isAdmin()) { try { [USERS, AUD] = await Promise.all([api('GET', '/api/users'), api('GET', '/api/audit?limit=100')]); } catch (e) { fail(e); } }
    draw();
  }
  async function reload(msg) { try { await load(); if (tab === 7 && isAdmin()) [USERS, AUD] = await Promise.all([api('GET', '/api/users'), api('GET', '/api/audit?limit=100')]); draw(); if (msg) note(msg, 'ok'); } catch (e) { fail(e); } }

  // ---------------------------------------------------------------- actions
  const URL_OF = { reg: '/api/transactions/', trk: '/api/mous/', bud: '/api/budget/' };
  async function editField(el) {
    const d = el.dataset, row = S[d.t].find((r) => r.id === +d.id);
    if (!row) return;
    let patch;
    if (d.j != null) { const arr = [...row[d.k]]; arr[+d.j] = el.value; patch = { [d.k]: arr }; }
    else patch = { [d.k]: el.type === 'number' ? (el.value === '' ? '' : +el.value) : el.value };
    if (d.t === 'reg' && d.k === 'ccy' && el.value !== S.rep && !(+row.fx > 0)) {
      const v = window.prompt(`FX rate: 1 ${el.value} = ? ${S.rep}`);
      if (v === null || !(+v > 0)) { draw(); return; }
      patch.fx = +v;
    }
    try { Object.assign(row, await api('PATCH', URL_OF[d.t] + row.id, patch)); note('Saved', 'ok'); } catch (e) { fail(e); }
    draw();
  }
  async function submitForm(btn) {
    const form = btn.closest('.frm'), kind = btn.dataset.submit, o = {};
    form.querySelectorAll('[data-f]').forEach((el) => { o[el.dataset.f] = el.value; });
    const target = { inc: ['/api/transactions', { type: 'Income' }], exp: ['/api/transactions', { type: 'Expenditure' }], mou: ['/api/mous', {}], bud: ['/api/budget', {}] }[kind];
    try { await api('POST', target[0], { ...o, ...target[1] }); ADD[kind] = false; await load(); draw(); note('Added', 'ok'); } catch (e) { const f = form.querySelector('.ferr'); if (f) f.textContent = e.message; fail(e); }
  }
  async function doLogin() {
    const u = $('#lu').value, p = $('#lp').value;
    try { const r = await api('POST', '/api/auth/login', { username: u, password: p }); ME = r.user; await load(); tab = 0; draw(); } catch (e) { const el = $('#lerr'); if (el) el.textContent = e.message; }
  }
  const lkReload = async (r) => { await reload(); return r; };

  document.addEventListener('click', async (e) => {
    const t = e.target, q = (s) => t.closest(s);
    try {
      if (NO && !q('.ngm') && !q('[data-ng]')) { NO = false; drawNav(); }
      let x;
      if ((x = q('[data-tab]'))) return goTab(+x.dataset.tab);
      if (q('[data-ng]')) { NO = !NO; return drawNav(); }
      if (q('#login')) return doLogin();
      if (q('#logout')) { try { await api('POST', '/api/auth/logout', {}); } catch (er) { /* ignore */ } ME = null; S = null; return showLogin(); }
      if ((x = q('[data-add]'))) { ADD[x.dataset.add] = !ADD[x.dataset.add]; return draw(); }
      if ((x = q('[data-submit]'))) return submitForm(x);
      if ((x = q('[data-del]'))) {
        const [k, id] = x.dataset.del.split(':');
        if (PD === x.dataset.del) { PD = null; await api('DELETE', URL_OF[k] + id); return reload('Deleted'); }
        PD = x.dataset.del; return draw();
      }
      if ((x = q('[data-view]'))) { VC = x.dataset.view; draw(); return scrollTo(0, 0); }
      if ((x = q('[data-gview]'))) { VG = x.dataset.gview; draw(); return scrollTo(0, 0); }
      if ((x = q('[data-gfilter]'))) { S.gf = U.gf = x.dataset.gfilter; saveUI(); VG = null; tab = 0; draw(); return scrollTo(0, 0); }
      if (q('#gback')) { VG = null; return draw(); }
      if (q('#vback')) { VC = null; return draw(); }
      if (q('#sall')) { U.showAll = !U.showAll; saveUI(); return draw(); }
      if ((x = q('[data-rp]'))) { U.rp = x.dataset.rp; saveUI(); return draw(); }
      if ((x = q('[data-nt]'))) { try { await navigator.clipboard.writeText(FU[+x.dataset.nt].txt); note('Message copied - paste it into an email to the partner', 'ok'); } catch (er) { note('Could not copy automatically', 'err'); } return; }
      if ((x = q('[data-lkadd]'))) {
        const k = x.dataset.lkadd, inp = $('#lkn-' + k);
        await api('POST', '/api/lookups/' + k, { name: inp.value }); return reload('Added');
      }
      if ((x = q('[data-lkdel]'))) {
        if (!window.confirm(`Remove "${x.dataset.name}"?`)) return;
        await api('DELETE', `/api/lookups/${x.dataset.lkdel}?name=${encodeURIComponent(x.dataset.name)}`); return reload('Removed');
      }
      if ((x = q('[data-uadd]'))) {
        const form = x.closest('.frm'), o = {};
        form.querySelectorAll('[data-f]').forEach((el) => { o[el.dataset.f] = el.value; });
        try { await api('POST', '/api/users', o); return reload('User added'); } catch (er) { form.querySelector('.ferr').textContent = er.message; return; }
      }
      if ((x = q('[data-upw]'))) {
        const pw = window.prompt('New password (at least 10 characters)');
        if (pw) { await api('PATCH', '/api/users/' + x.dataset.upw, { password: pw }); note('Password changed; that user must sign in again', 'ok'); }
        return;
      }
      if (q('#audref')) return reload();
    } catch (er) { fail(er); }
  });

  document.addEventListener('change', async (e) => {
    const t = e.target, d = t.dataset;
    try {
      if (t.id === 'gf') { S.gf = U.gf = t.value; saveUI(); return draw(); }
      if (t.id === 'rfy') { U.fy = t.value === 'fy'; saveUI(); return draw(); }
      if (d.t) return editField(t);
      if (d.lk) {
        if (t.value.trim() === d.old) return;
        try { await api('PATCH', '/api/lookups/' + d.lk, { name: d.old, newName: t.value }); return reload('Renamed'); } catch (er) { fail(er); return reload(); }
      }
      if (d.pct != null) {
        const p = [...document.querySelectorAll('[data-pct]')].map((el) => (+el.value || 0) / 100);
        const r = await api('PUT', '/api/settings', { pct: p }); CFGWARN = r.warnings; return reload('Saved');
      }
      if (t.id === 'rep') { const r = await api('PUT', '/api/settings', { rep: t.value }); CFGWARN = r.warnings; return reload('Reporting currency changed'); }
      if (t.id === 'cpa') { await api('PUT', '/api/settings', { cpa: t.value === '' ? '' : +t.value }); return reload('Saved'); }
      if (d.urole) { await api('PATCH', '/api/users/' + d.urole, { role: t.value }); return reload('Saved'); }
      if (d.uact) { await api('PATCH', '/api/users/' + d.uact, { active: t.value === '1' }); return reload('Saved'); }
    } catch (er) { fail(er); if (d.urole || d.uact || t.id === 'rep' || t.id === 'cpa' || d.pct != null) reload(); }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && NO) { NO = false; drawNav(); }
    if (e.key === 'Enter' && (e.target.id === 'lu' || e.target.id === 'lp')) doLogin();
  });

  // ---------------------------------------------------------------- boot
  (async function boot() {
    try {
      const r = await api('GET', '/api/auth/me');
      if (!r.user) return showLogin();
      ME = r.user; await load(); draw();
    } catch (e) { if (!e.silent) { $('#m').innerHTML = `<p class="note neg" role="alert">${esc(e.message)}</p>`; } }
  })();
})();
