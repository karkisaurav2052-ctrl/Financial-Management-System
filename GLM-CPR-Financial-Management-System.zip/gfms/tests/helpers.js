'use strict';
const { open } = require('../server/db');
const { createApp } = require('../server/app');
const { seedOpening } = require('../server/seed');
const store = require('../server/store');

/** Start an app on a random port with an in-memory database. */
async function boot({ seed = true } = {}) {
  const db = open(':memory:');
  if (seed) seedOpening(db);
  const users = {
    admin: store.createUser(db, { username: 'admin1', password: 'admin-password-1', role: 'admin', name: 'Admin One' }),
    editor: store.createUser(db, { username: 'editor1', password: 'editor-password-1', role: 'editor' }),
    viewer: store.createUser(db, { username: 'viewer1', password: 'viewer-password-1', role: 'viewer' }),
  };
  const app = createApp(db);
  const server = await new Promise((res) => { const s = app.listen(0, '127.0.0.1', () => res(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;

  function client() {
    let cookie = '';
    const call = async (method, path, body, headers = {}) => {
      const h = { ...headers };
      if (cookie) h.cookie = cookie;
      let payload;
      if (body !== undefined) { payload = typeof body === 'string' ? body : JSON.stringify(body); h['content-type'] = h['content-type'] || 'application/json'; }
      const r = await fetch(base + path, { method, headers: h, body: payload });
      const set = r.headers.get('set-cookie');
      if (set) cookie = set.startsWith('sid=;') ? '' : set.split(';')[0];
      const text = await r.text();
      let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
      return { status: r.status, json, text, headers: r.headers };
    };
    return {
      get: (p, h) => call('GET', p, undefined, h), post: (p, b, h) => call('POST', p, b, h), patch: (p, b) => call('PATCH', p, b),
      put: (p, b) => call('PUT', p, b), del: (p) => call('DELETE', p),
      login: async (u, pw) => { const r = await call('POST', '/api/auth/login', { username: u, password: pw }); if (r.status !== 200) throw new Error('login failed ' + r.status); return r; },
      raw: call,
    };
  }
  const as = async (who) => { const c = client(); await c.login(who + '1', who + '-password-1'); return c; };
  const close = () => new Promise((res) => server.close(() => { db.close(); res(); }));
  return { db, base, client, as, close, users };
}

const goodExp = (o = {}) => ({ type: 'Expenditure', date: '2026-03-01', g: 'PRG00626', c: 'Kenya', w: 'Seed funding', cat: 'Partner disbursement', ms: 'M1', d: 'Test', ccy: 'AUD', amt: 100, st: 'Outstanding', due: '2026-04-01', ...o });
module.exports = { boot, goodExp };
