'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { boot, goodExp } = require('./helpers');
const F = require('../shared/finance');

let T, admin, editor, viewer;
test.before(async () => { T = await boot(); admin = await T.as('admin'); editor = await T.as('editor'); viewer = await T.as('viewer'); });
test.after(async () => { await T.close(); });

const state = async () => { const S = (await admin.get('/api/state')).json; S.gf = ''; return S; };

test('opening data loads and matches hand-calculated totals', async () => {
  const S = await state();
  assert.equal(S.rep, 'AUD');
  assert.deepEqual(S.pct, [0.3, 0.3, 0.4]);
  assert.equal(S.bud.length, 40);
  assert.equal(S.reg.length, 20);
  assert.equal(S.trk.length, 19, 'blank placeholder tracker rows are not imported');
  assert.equal(S.L.countries[0], 'Global');
  assert.ok(S.L.countries.length > 190);
  assert.equal(F.totalBudget(S), 445584);
  assert.equal(F.incomeTotal(S), 434481);
  assert.equal(F.paidTotal(S), 57182.06);
  assert.equal(F.outTotal(S), 0);
  const d = F.dashboard(S, '2026-10-25');
  assert.equal(d.surplus, -11103);
  assert.equal(d.remaining, 388401.94);
  // per-grant budget ties out to the total
  const g = F.grantSummary(S);
  assert.equal(g.total.b, 445584);
  assert.equal(g.rows.find((r) => r.g === 'PRG00626').a, 286000);
  // salary: 5 named staff + 1 unallocated budget line
  const sal = F.groupSummary(S, 'w').rows.find((r) => r.name === 'Salary');
  assert.equal(sal.b, 19103);
  assert.equal(sal.p, 9972); // 4236+4236+900+600
  assert.deepEqual(sal.sub.map((x) => x.name), ['Atika', 'Badsha', 'Rafsan', 'Sangwani', 'Saurav', 'Other / unallocated']);
  assert.equal(sal.sub.at(-1).b, 1);
  const rec = F.reconciliation(S);
  assert.ok(rec.checks.filter((c) => c.id !== 'docs').every((c) => c.ok), 'country/workstream/fx/shares reconcile');
});

test('server reports use the same numbers as the shared core', async () => {
  const r = (await admin.get('/api/reports/summary?today=2026-10-25')).json;
  assert.equal(r.dashboard.budget, 445584);
  assert.equal(r.dashboard.paid, 57182.06);
  assert.equal(r.grants.total.a, 434481);
  assert.equal(r.workstreams.total.b, 445584);
  assert.equal(r.reconciliation.paid, 57182.06);
  const f = (await admin.get('/api/reports/summary?today=2026-10-25&gf=NHMRC')).json;
  assert.equal(f.dashboard.budget, 97500); // independently summed from the opening data (see python check)
  assert.equal((await admin.get('/api/reports/summary?gf=Nope')).status, 422);
  assert.equal((await admin.get('/api/reports/summary?mode=week')).status, 422);
  assert.equal((await admin.get('/api/reports/summary?today=2026-13-45')).status, 422);
  const csv = await admin.get('/api/reports/period.csv?mode=year');
  assert.equal(csv.status, 200);
  assert.match(csv.headers.get('content-type'), /text\/csv/);
  assert.match(csv.text, /Undated \(opening balances\)/);
});

test('authentication: required, wrong password, logout, deactivation', async () => {
  const anon = T.client();
  assert.equal((await anon.get('/api/state')).status, 401);
  assert.equal((await anon.get('/api/auth/me')).json.user, null);
  assert.equal((await anon.raw('POST', '/api/auth/login', { username: 'admin1', password: 'wrong' })).status, 401);
  assert.equal((await anon.raw('POST', '/api/auth/login', { username: 'nobody', password: 'x' })).status, 401);
  assert.equal((await anon.raw('POST', '/api/auth/login', { username: { $ne: 1 }, password: [] })).status, 401);
  const c = await T.as('viewer');
  const set = (await c.get('/api/auth/me')).json.user;
  assert.equal(set.role, 'viewer');
  assert.equal((await c.post('/api/auth/logout', {})).status, 200);
  assert.equal((await c.get('/api/state')).status, 401, 'session destroyed on logout');
  // cookie flags
  const l = await T.client().raw('POST', '/api/auth/login', { username: 'viewer1', password: 'viewer-password-1' });
  const ck = l.headers.get('set-cookie');
  assert.match(ck, /HttpOnly/); assert.match(ck, /SameSite=Strict/);
  assert.ok(!JSON.stringify(l.json).includes('password'));
});

test('login throttling blocks brute force', async () => {
  const c = T.client();
  for (let i = 0; i < 8; i++) assert.equal((await c.raw('POST', '/api/auth/login', { username: 'victim', password: 'x' + i })).status, 401);
  assert.equal((await c.raw('POST', '/api/auth/login', { username: 'victim', password: 'x' })).status, 429);
});

test('roles: viewer read-only, editor edits data not config, admin everything', async () => {
  assert.equal((await viewer.get('/api/state')).status, 200);
  assert.equal((await viewer.post('/api/transactions', goodExp())).status, 403);
  assert.equal((await viewer.post('/api/budget', { g: 'NHMRC', c: 'Kenya', w: 'Seed funding', a: 1 })).status, 403);
  assert.equal((await viewer.get('/api/users')).status, 403);
  assert.equal((await editor.get('/api/users')).status, 403);
  assert.equal((await editor.put('/api/settings', { rep: 'USD' })).status, 403);
  assert.equal((await editor.post('/api/lookups/grants', { name: 'X' })).status, 403);
  assert.equal((await editor.get('/api/audit')).status, 403);
  const r = await editor.post('/api/transactions', goodExp({ d: 'editor row' }));
  assert.equal(r.status, 201);
  assert.equal((await viewer.del('/api/transactions/' + r.json.id)).status, 403);
  assert.equal((await editor.del('/api/transactions/' + r.json.id)).status, 200);
  assert.equal((await T.client().post('/api/transactions', goodExp())).status, 401);
});

test('transactions: create / read / update / delete round trip with audit', async () => {
  const c = await editor.post('/api/transactions', goodExp({ amt: 1234.56, doc: 'INV-1' }));
  assert.equal(c.status, 201);
  const id = c.json.id;
  assert.deepEqual([c.json.amt, c.json.st, c.json.ver, c.json.fx, c.json.pdate], [1234.56, 'Outstanding', 'No', '', '']);
  const before = F.outTotal(await state());
  assert.equal(before, 1234.56);
  const u = await editor.patch('/api/transactions/' + id, { st: 'Paid', pdate: '2026-03-15', ver: 'Yes' });
  assert.equal(u.status, 200);
  assert.deepEqual([u.json.st, u.json.pdate, u.json.ver, u.json.amt], ['Paid', '2026-03-15', 'Yes', 1234.56]);
  const S = await state();
  assert.equal(F.outTotal(S), 0);
  assert.equal(F.paidTotal(S), 58416.62); // 57182.06 + 1234.56
  assert.equal(F.disbursed(S, 'Kenya'), 3734.56); // 2500 opening + 1234.56
  const log = (await admin.get(`/api/audit?entity=transaction&entityId=${id}`)).json;
  assert.deepEqual(log.map((l) => l.action), ['update', 'create']);
  assert.equal(log[0].before.st, 'Outstanding'); assert.equal(log[0].after.st, 'Paid'); assert.equal(log[0].user, 'editor1');
  assert.equal((await editor.del('/api/transactions/' + id)).status, 200);
  assert.equal((await editor.del('/api/transactions/' + id)).status, 404);
  assert.equal((await editor.patch('/api/transactions/' + id, { amt: 1 })).status, 404);
  assert.equal((await admin.get(`/api/audit?entity=transaction&entityId=${id}`)).json[0].action, 'delete');
});

test('transactions: every validation rule rejects bad input with the right field', async () => {
  const cases = [
    [{ type: 'Transfer' }, 'type'], [{ g: 'Nope' }, 'g'], [{ g: '' }, 'g'], [{ c: 'Atlantis' }, 'c'], [{ c: '' }, 'c'], [{ w: 'Nope' }, 'w'], [{ w: '' }, 'w'], [{ cat: 'Nope' }, 'cat'], [{ cat: '' }, 'cat'],
    [{ ms: 'M9' }, 'ms'], [{ ccy: 'XXX' }, 'ccy'], [{ amt: -5 }, 'amt'], [{ amt: 0 }, 'amt'], [{ amt: '' }, 'amt'], [{ amt: 'abc' }, 'amt'], [{ amt: 10.005 }, 'amt'], [{ amt: 1e13 }, 'amt'],
    [{ amt: Infinity }, 'amt'], [{ date: '2026-02-30' }, 'date'], [{ date: '01/02/2026' }, 'date'], [{ date: '1800-01-01' }, 'date'], [{ due: 'soon' }, 'due'],
    [{ ccy: 'USD' }, 'fx'], [{ ccy: 'USD', fx: 0 }, 'fx'], [{ ccy: 'USD', fx: -1 }, 'fx'], [{ st: 'Pending' }, 'st'], [{ st: 'Paid', date: '2026-03-10', pdate: '2026-03-01' }, 'pdate'],
    [{ d: 'x'.repeat(501) }, 'd'], [{ doc: 'x'.repeat(101) }, 'doc'], [{ ver: 'Maybe' }, 'ver'], [{ d: 'bad\u0000char' }, 'd'],
  ];
  for (const [patch, field] of cases) {
    const r = await editor.post('/api/transactions', goodExp(patch));
    assert.equal(r.status, 422, JSON.stringify(patch));
    assert.equal(r.json.error.field, field, JSON.stringify(patch) + ' -> ' + r.json.error.message);
  }
  assert.equal((await editor.post('/api/transactions', [1, 2])).status, 422);
  assert.equal((await editor.post('/api/transactions', 'not json')).status, 400);
  // nothing leaked into the database by the failed attempts
  assert.equal((await state()).reg.length, 20);
});

test('transactions: foreign currency, income rules, no type switching', async () => {
  const fx = await editor.post('/api/transactions', goodExp({ ccy: 'USD', fx: 1.5, amt: 100 }));
  assert.equal(fx.status, 201);
  assert.equal(F.RA(fx.json, 'AUD'), 150);
  // a foreign row cannot lose its FX rate
  assert.equal((await editor.patch('/api/transactions/' + fx.json.id, { fx: '' })).status, 422);
  // switching currency back to the reporting currency drops the FX rate
  const back = await editor.patch('/api/transactions/' + fx.json.id, { ccy: 'AUD' });
  assert.equal(back.json.fx, '');
  // changing to foreign currency needs the rate in the same request
  assert.equal((await editor.patch('/api/transactions/' + fx.json.id, { ccy: 'EUR' })).status, 422);
  assert.equal((await editor.patch('/api/transactions/' + fx.json.id, { ccy: 'EUR', fx: 1.6 })).json.fx, 1.6);
  const inc = await editor.post('/api/transactions', { type: 'Income', date: '2026-02-01', g: 'DFAT', amt: 5000, ccy: 'AUD', w: 'Salary', cat: 'Salary', ms: 'M1', st: 'Paid', due: '2026-05-01', pdate: '2026-06-01' });
  assert.equal(inc.status, 201);
  assert.deepEqual([inc.json.c, inc.json.st, inc.json.w, inc.json.cat, inc.json.ms, inc.json.due, inc.json.pdate], ['Global', 'Available', '', '', '', '', ''], 'income is normalised');
  assert.equal((await editor.patch('/api/transactions/' + inc.json.id, { type: 'Expenditure' })).status, 422);
  assert.equal((await editor.patch('/api/transactions/' + inc.json.id, { amt: 0 })).status, 422);
  for (const x of [fx, inc]) await editor.del('/api/transactions/' + x.json.id);
});

test('transactions: ids, unknown keys and mass-assignment are handled safely', async () => {
  assert.equal((await editor.patch('/api/transactions/abc', { amt: 1 })).status, 404);
  assert.equal((await editor.patch('/api/transactions/-1', { amt: 1 })).status, 404);
  assert.equal((await editor.patch('/api/transactions/1.5', { amt: 1 })).status, 404);
  const c = await editor.post('/api/transactions', goodExp({ id: 999999, created_by: 1, verified: 1, hacked: true }));
  assert.equal(c.status, 201);
  assert.notEqual(c.json.id, 999999);
  assert.ok(!('hacked' in c.json));
  const sqli = await editor.post('/api/transactions', goodExp({ d: "'); DROP TABLE transactions;--" }));
  assert.equal(sqli.status, 201);
  assert.equal(sqli.json.d, "'); DROP TABLE transactions;--");
  assert.ok((await state()).reg.length > 20);
  await editor.del('/api/transactions/' + c.json.id); await editor.del('/api/transactions/' + sqli.json.id);
});

test('budget lines: CRUD and validation', async () => {
  const c = await editor.post('/api/budget', { g: 'DFAT', c: 'Kenya', w: 'Travel', d: 'Trip', a: 2500.5 });
  assert.equal(c.status, 201);
  assert.equal(F.totalBudget(await state()), 445584 + 2500.5);
  assert.equal((await editor.patch('/api/budget/' + c.json.id, { a: 3000 })).json.a, 3000);
  for (const [p, f] of [[{ g: 'X' }, 'g'], [{ c: 'X' }, 'c'], [{ w: 'X' }, 'w'], [{ a: -1 }, 'a'], [{ a: 'x' }, 'a'], [{ a: 1.001 }, 'a']]) {
    const r = await editor.patch('/api/budget/' + c.json.id, p);
    assert.equal(r.status, 422); assert.equal(r.json.error.field, f);
  }
  assert.equal((await editor.post('/api/budget', { c: 'Kenya', w: 'Travel', a: 1 })).status, 422, 'grant required');
  assert.equal((await editor.del('/api/budget/' + c.json.id)).status, 200);
  assert.equal(F.totalBudget(await state()), 445584);
  assert.equal((await editor.del('/api/budget/' + c.json.id)).status, 404);
});

test('MoU tracker: CRUD, uniqueness, date order, milestone arrays', async () => {
  const bad = [[{ c: 'Global' }, 'c'], [{ c: 'Kenya' }, null], [{ c: 'Nowhere' }, 'c'], [{ c: 'Chad', em: 'not-an-email' }, 'em'], [{ c: 'Chad', s: '2026-05-01', e: '2026-04-01' }, 'e'],
    [{ c: 'Chad', due: ['2026-01-01'] }, 'due'], [{ c: 'Chad', due: ['x', '', ''] }, 'due[0]'], [{ c: 'Chad', conf: ['Maybe', '', ''] }, 'conf[0]'], [{ c: 'Chad', f: -1 }, 'f'], [{ c: 'Chad', g: 'Nope' }, 'g']];
  for (const [p, f] of bad) {
    const r = await editor.post('/api/mous', p);
    assert.ok([409, 422].includes(r.status), JSON.stringify(p));
    if (f) assert.equal(r.json.error.field, f, r.json.error.message);
  }
  assert.equal((await editor.post('/api/mous', { c: 'Kenya' })).status, 409, 'one MoU row per country');
  const c = await editor.post('/api/mous', { c: 'Chad', p: 'Partner Chad', em: 'a@b.org', g: 'DFAT', f: 9000, due: ['2026-12-01', '', ''], conf: ['', 'No', ''] });
  assert.equal(c.status, 201);
  assert.deepEqual([c.json.due, c.json.conf, c.json.f], [['2026-12-01', '', ''], ['', 'No', ''], 9000]);
  const u = await editor.patch('/api/mous/' + c.json.id, { conf: ['Yes', 'No', ''], f: 12000 });
  assert.deepEqual([u.json.conf, u.json.due[0], u.json.f], [['Yes', 'No', ''], '2026-12-01', 12000]);
  assert.equal((await editor.patch('/api/mous/' + c.json.id, { c: 'Kenya' })).status, 409);
  assert.equal((await editor.del('/api/mous/' + c.json.id)).status, 200);
  assert.equal((await state()).trk.some((t) => t.c === 'Chad'), false);
  const left = T.db.prepare('SELECT COUNT(*) AS n FROM mou_milestones WHERE mou_id=?').get(c.json.id).n;
  assert.equal(left, 0, 'milestones cascade-deleted');
});

test('lookups: add, rename (propagates everywhere), delete protections', async () => {
  assert.equal((await admin.post('/api/lookups/grants', { name: 'New Grant' })).status, 201);
  assert.equal((await admin.post('/api/lookups/grants', { name: 'new grant' })).status, 409, 'case-insensitive duplicate');
  assert.equal((await admin.post('/api/lookups/grants', { name: '  ' })).status, 422);
  assert.equal((await admin.post('/api/lookups/nope', { name: 'x' })).status, 404);
  assert.equal((await admin.post('/api/lookups/ccys', { name: 'usdx' })).status, 422);
  assert.equal((await admin.post('/api/lookups/ccys', { name: 'jpy' })).json.name, 'JPY');
  // rename an in-use grant: transactions, budget and MoUs follow automatically
  assert.equal((await admin.patch('/api/lookups/grants', { name: 'SSEAC', newName: 'SSEAC-2' })).status, 200);
  let S = await state();
  assert.ok(S.reg.some((r) => r.g === 'SSEAC-2') && !S.reg.some((r) => r.g === 'SSEAC'));
  assert.ok(S.bud.some((b) => b.g === 'SSEAC-2'));
  assert.equal(F.grantSummary(S).rows.find((r) => r.g === 'SSEAC-2').b, 19981);
  await admin.patch('/api/lookups/grants', { name: 'SSEAC-2', newName: 'SSEAC' });
  assert.equal((await admin.patch('/api/lookups/grants', { name: 'SSEAC', newName: 'NHMRC' })).status, 409);
  assert.equal((await admin.patch('/api/lookups/ccys', { name: 'JPY', newName: 'YEN' })).status, 422);
  // delete: unused ok, used blocked
  assert.equal((await admin.del('/api/lookups/grants?name=' + encodeURIComponent('New Grant'))).status, 200);
  const used = await admin.del('/api/lookups/grants?name=NHMRC');
  assert.equal(used.status, 409); assert.match(used.json.error.message, /used by \d+ record/);
  assert.equal((await admin.del('/api/lookups/countries?name=Global')).status, 409, 'bucket protected');
  assert.equal((await admin.del('/api/lookups/ccys?name=AUD')).status, 409, 'reporting currency protected');
  assert.equal((await admin.del('/api/lookups/ccys?name=JPY')).status, 200);
  assert.equal((await admin.del('/api/lookups/works?name=Salary')).status, 409, 'reserved');
  assert.equal((await admin.patch('/api/lookups/works', { name: 'Salary', newName: 'Pay' })).status, 409, 'reserved');
  assert.equal((await admin.patch('/api/lookups/cats', { name: 'Partner disbursement', newName: 'X' })).status, 409, 'reserved');
  assert.equal((await admin.del('/api/lookups/grants?name=Missing')).status, 422);
});

test('settings: reporting currency, milestone shares, CPA total', async () => {
  assert.equal((await admin.put('/api/settings', { pct: [0.5, 0.5] })).status, 422);
  assert.equal((await admin.put('/api/settings', { pct: [0.5, 0.5, 2] })).status, 422);
  assert.equal((await admin.put('/api/settings', { pct: ['a', 0, 0] })).status, 422);
  const w = await admin.put('/api/settings', { pct: [0.4, 0.4, 0.4] });
  assert.match(w.json.warnings[0], /100%/);
  assert.deepEqual((await state()).pct, [0.4, 0.4, 0.4]);
  await admin.put('/api/settings', { pct: [0.3, 0.3, 0.4] });
  assert.equal((await admin.put('/api/settings', { cpa: 57182.06 })).json.settings.cpa, 57182.06);
  assert.equal((await admin.put('/api/settings', { cpa: -1 })).status, 422);
  assert.equal((await admin.put('/api/settings', { cpa: '' })).json.settings.cpa, null);
  assert.equal((await admin.put('/api/settings', { rep: 'ZZZ' })).status, 422);
  // switching reporting currency warns about rows lacking an FX rate
  const r = await admin.put('/api/settings', { rep: 'USD' });
  assert.equal(r.json.settings.rep, 'USD');
  assert.match(r.json.warnings[0], /no FX rate/);
  assert.equal((await admin.put('/api/settings', { rep: 'aud' })).json.settings.rep, 'AUD');
});

test('users: create, validation, last-admin and self protections, password change kills sessions', async () => {
  assert.equal((await admin.post('/api/users', { username: 'x', password: 'long-enough-pass', role: 'viewer' })).status, 422);
  assert.equal((await admin.post('/api/users', { username: 'newbie', password: 'short', role: 'viewer' })).status, 422);
  assert.equal((await admin.post('/api/users', { username: 'newbie', password: 'long-enough-pass', role: 'root' })).status, 422);
  assert.equal((await admin.post('/api/users', { username: 'ADMIN1', password: 'long-enough-pass', role: 'viewer' })).status, 409);
  const n = await admin.post('/api/users', { username: 'newbie', password: 'long-enough-pass', role: 'editor' });
  assert.equal(n.status, 201);
  assert.ok(!('password_hash' in n.json) && !JSON.stringify(n.json).includes('scrypt'));
  const nc = T.client(); await nc.login('newbie', 'long-enough-pass');
  assert.equal((await nc.get('/api/state')).status, 200);
  await admin.patch('/api/users/' + n.json.id, { password: 'another-long-pass' });
  assert.equal((await nc.get('/api/state')).status, 401, 'sessions revoked on password change');
  await nc.login('newbie', 'another-long-pass');
  await admin.patch('/api/users/' + n.json.id, { active: false });
  assert.equal((await nc.get('/api/state')).status, 401, 'sessions revoked on deactivation');
  assert.equal((await T.client().raw('POST', '/api/auth/login', { username: 'newbie', password: 'another-long-pass' })).status, 401);
  assert.equal((await admin.patch('/api/users/' + T.users.admin.id, { active: false })).status, 409);
  assert.equal((await admin.patch('/api/users/' + T.users.admin.id, { role: 'viewer' })).status, 409, 'last admin');
  assert.equal((await admin.patch('/api/users/9999', { role: 'viewer' })).status, 404);
  assert.equal((await admin.get('/api/users')).json.length, 4);
});

test('security: CSRF, content-type, malformed/oversized bodies, headers, secrets', async () => {
  const r = await editor.raw('POST', '/api/transactions', goodExp(), { origin: 'https://evil.example' });
  assert.equal(r.status, 403);
  assert.equal((await editor.raw('POST', '/api/transactions', JSON.stringify(goodExp()), { 'content-type': 'text/plain' })).status, 415);
  assert.equal((await editor.raw('POST', '/api/transactions', '{bad', {})).status, 400);
  assert.equal((await editor.raw('POST', '/api/transactions', JSON.stringify({ d: 'x'.repeat(200000) }))).status, 413);
  const h = (await editor.get('/api/state')).headers;
  assert.match(h.get('content-security-policy'), /default-src 'self'/);
  assert.equal(h.get('x-content-type-options'), 'nosniff');
  assert.equal(h.get('x-frame-options'), 'DENY');
  assert.equal(h.get('x-powered-by'), null);
  assert.equal(h.get('cache-control'), 'no-store');
  assert.equal((await T.client().get('/api/nope')).status, 404);
  assert.equal((await T.client().get('/server/db.js')).status, 404);
  assert.equal((await T.client().get('/server/schema.sql')).status, 404);
  assert.equal((await T.client().get('/data/gfms.sqlite')).status, 404);
});

test('exports: transaction CSV is formula-injection safe and complete', async () => {
  const c = await editor.post('/api/transactions', goodExp({ d: '=HYPERLINK("http://evil","x")', doc: '@cmd' }));
  const csv = (await viewer.get('/api/export/transactions.csv')).text;
  assert.equal(csv.split('\r\n').filter(Boolean).length, 1 + (await state()).reg.length);
  assert.ok(csv.includes(`"'=HYPERLINK(""http://evil"",""x"")"`));
  assert.ok(csv.includes(`"'@cmd"`));
  assert.ok(!/(^|,)"=/m.test(csv));
  await editor.del('/api/transactions/' + c.json.id);
  assert.equal((await T.client().get('/api/export/transactions.csv')).status, 401);
});

test('database constraints hold even if the API is bypassed', async () => {
  const run = (sql, ...a) => T.db.prepare(sql).run(...a);
  const ins = (type, status, amt = 100, ccy = 'AUD') => run('INSERT INTO transactions(txn_type,grant_id,country_id,currency,amount_minor,status) VALUES (?,1,1,?,?,?)', type, ccy, amt, status);
  assert.throws(() => ins('Income', 'Paid'), /constraint/i);
  assert.throws(() => ins('Expenditure', 'Available'), /constraint/i);
  assert.throws(() => ins('Expenditure', 'Paid', -1), /constraint/i);
  assert.throws(() => ins('Expenditure', 'Paid', 1, 'ZZZ'), /constraint/i);
  assert.throws(() => run('INSERT INTO transactions(txn_type,grant_id,country_id,currency,amount_minor,status,txn_date) VALUES (?,1,1,?,?,?,?)', 'Expenditure', 'AUD', 1, 'Paid', 'yesterday'), /constraint/i);
  assert.throws(() => run('INSERT INTO transactions(txn_type,grant_id,country_id,currency,amount_minor,status,fx_rate) VALUES (?,1,1,?,?,?,0)', 'Expenditure', 'AUD', 1, 'Paid'), /constraint/i);
  assert.throws(() => run('INSERT INTO transactions(txn_type,grant_id,country_id,currency,amount_minor,status) VALUES (?,999,1,?,?,?)', 'Expenditure', 'AUD', 1, 'Paid'), /constraint/i, 'FK');
  assert.throws(() => run("INSERT INTO countries(name,is_bucket) VALUES ('Second bucket',1)"), /constraint|unique/i, 'only one bucket');
  assert.throws(() => run('DELETE FROM grants WHERE id=1'), /constraint/i, 'RESTRICT on in-use grant');
  assert.throws(() => run("INSERT INTO users(username,password_hash,role) VALUES ('zz','h','god')"), /constraint/i);
});

test('mutations are atomic: a failed request changes nothing', async () => {
  const before = JSON.stringify(await state());
  const r = await editor.patch('/api/mous/1', { due: ['2026-01-01', 'bad', ''] });
  assert.equal(r.status, 422);
  assert.equal(JSON.stringify(await state()), before);
  const auditN = T.db.prepare('SELECT COUNT(*) AS n FROM audit_log').get().n;
  await editor.post('/api/transactions', goodExp({ amt: -1 }));
  assert.equal(T.db.prepare('SELECT COUNT(*) AS n FROM audit_log').get().n, auditN, 'failed requests are not audited as changes');
});

test('audit log is admin-only, ordered, and capped', async () => {
  const a = (await admin.get('/api/audit?limit=5')).json;
  assert.equal(a.length, 5);
  assert.ok(a[0].id > a[1].id);
  assert.equal((await admin.get('/api/audit?limit=99999')).status, 200);
  assert.equal((await viewer.get('/api/audit')).status, 403);
});
