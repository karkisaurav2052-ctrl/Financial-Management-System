'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { open } = require('../server/db');
const { seedOpening, seedDemo } = require('../server/seed');
const store = require('../server/store');
const F = require('../shared/finance');

test('seeding refuses to run on a non-empty database', () => {
  const db = open(':memory:');
  seedOpening(db);
  assert.throws(() => seedOpening(db), /already contains data/);
  db.close();
});

test('demo seed produces the documented overdue / due-soon scenarios', () => {
  const db = open(':memory:');
  seedOpening(db);
  seedDemo(db, '2026-10-26');
  const S = store.getState(db); S.gf = '';
  assert.equal(F.incomeTotal(S), 434481 + 75000);
  assert.equal(F.outTotal(S), 500 + 1200 + 750 + 2400 + 1800 + 900 + 300);
  assert.equal(F.paidTotal(S), 57182.06 + 14200);
  const fu = F.followUps(S, '2026-10-26').map((p) => p.c).sort();
  assert.deepEqual(fu, ['Brazil', 'Pakistan', 'Thailand'], 'India is overdue but its documents are confirmed');
  const o = F.outstandingDue(S, '2026-10-26');
  assert.equal(o.noDue, 1);
  assert.deepEqual(o.rows.map((r) => r.amount), [500, 1200, 750, 2400, 1800]);
  assert.ok(F.reconciliation(S).checks.filter((c) => c.id !== 'docs').every((c) => c.ok));
  db.close();
});

test('a failed seed rolls back completely', () => {
  const db = open(':memory:');
  const bad = JSON.parse(JSON.stringify(require('../data/opening-data.json')));
  bad.reg[0].amt = -5;
  assert.throws(() => seedOpening(db, bad, []));
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM grants').get().n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM settings').get().n, 0);
  db.close();
});
