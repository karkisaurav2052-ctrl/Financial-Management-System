'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { JSDOM, VirtualConsole } = require('jsdom');
const { boot } = require('./helpers');

let T;
test.before(async () => { T = await boot(); });
test.after(async () => { await T.close(); });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(fn, what, ms = 4000) {
  const t0 = Date.now();
  for (;;) { try { const v = fn(); if (v) return v; } catch (e) { /* retry */ } if (Date.now() - t0 > ms) throw new Error('Timed out waiting for ' + what); await sleep(15); }
}

/** Open the app in jsdom with a cookie-aware fetch shim talking to the real server. */
async function openApp() {
  const errors = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', (e) => errors.push('jsdomError: ' + (e.detail || e.message)));
  vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));
  let cookie = '';
  const dom = await JSDOM.fromURL(T.base + '/', {
    runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w) {
      w.fetch = async (u, o = {}) => {
        const h = { ...(o.headers || {}) }; if (cookie) h.cookie = cookie;
        const r = await fetch(new URL(u, T.base), { ...o, headers: h });
        const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.startsWith('sid=;') ? '' : sc.split(';')[0];
        return r;
      };
      w.prompt = () => null; w.confirm = () => true; w.scrollTo = () => {};
    },
  });
  const w = dom.window, d = w.document;
  const q = (s) => d.querySelector(s), qa = (s) => [...d.querySelectorAll(s)];
  const change = (el, v) => { if (v !== undefined) el.value = v; el.dispatchEvent(new w.Event('change', { bubbles: true })); };
  const click = (el) => el.click();
  const text = () => d.body.textContent.replace(/\s+/g, ' ');
  const login = async (u, p) => {
    await waitFor(() => q('#lu'), 'login form');
    q('#lu').value = u; q('#lp').value = p; click(q('#login'));
  };
  const goto = async (i, heading) => {
    if ([2, 3, 4, 8].includes(i)) { if (!q('.ngm')) click(q('[data-ng]')); click(q(`.ngm [data-tab="${i}"]`)); } else click(q(`#nav [data-tab="${i}"]`));
    await waitFor(() => !heading || q('main h2, main .top h2') && text().includes(heading), 'tab ' + heading);
  };
  return { dom, w, d, q, qa, change, click, text, login, goto, errors, close: () => { setTimeout(() => w.close(), 400).unref(); } };
}
const kpi = (ui, label) => { const k = ui.qa('.kp .k').find((x) => x.querySelector('span') && x.querySelector('span').textContent.trim() === label); return k && k.querySelector('b').textContent.trim(); };

test('login screen: bad password rejected, good password shows the dashboard with correct KPIs', async () => {
  const ui = await openApp();
  await waitFor(() => ui.q('.login'), 'login');
  assert.equal(ui.q('#nav').children.length, 0, 'no navigation before sign-in');
  await ui.login('admin1', 'wrong-password');
  await waitFor(() => ui.q('#lerr').textContent.includes('Incorrect'), 'error message');
  await ui.login('admin1', 'admin-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  assert.equal(kpi(ui, 'Total Budget Allocated'), '445,584.00');
  assert.equal(kpi(ui, 'Total Available Funding'), '434,481.00');
  assert.equal(kpi(ui, 'Actual Expenditure Paid'), '57,182.06');
  assert.equal(kpi(ui, 'Budget Remaining'), '388,401.94');
  assert.equal(kpi(ui, 'Budget Surplus / (Deficit)'), '-11,103.00');
  assert.ok(ui.q('.k.bad'), 'deficit card is flagged');
  assert.ok(ui.text().includes('12.8% of allocated budget spent'));
  assert.match(ui.q('#who').textContent, /Admin One.*admin/i);
  assert.deepEqual(ui.errors, []);
  ui.close();
});

test('every tab renders without errors; drill-downs and grant filter work', async () => {
  const ui = await openApp();
  await ui.login('admin1', 'admin-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  const heads = { 0: 'Funds and spending', 1: 'MoU and payment tracker', 2: 'Country Financials', 3: 'Grant Management', 4: 'Workstream Financials', 5: 'Financial Reporting', 6: 'Income', 7: 'Reporting currency and milestone shares', 8: 'Budget lines' };
  for (const i of [1, 2, 3, 4, 5, 6, 7, 8, 0]) { await ui.goto(i, heads[i]); }
  // Workstream: salary breakdown rows
  await ui.goto(4, 'Workstream Financials');
  assert.ok(ui.text().includes('Other / unallocated') && ui.text().includes('Badsha'));
  assert.ok(ui.qa('tr.t').at(-1).textContent.includes('445,584.00'));
  // Country drill-down
  await ui.goto(2, 'Country Financials');
  ui.click(ui.q('[data-view="Argentina"]'));
  await waitFor(() => ui.text().includes('Argentina: expenditure by heading'), 'country detail');
  assert.equal(kpi(ui, 'Budget'), '40,000.00'); assert.equal(kpi(ui, 'Paid'), '10,000.00');
  ui.click(ui.q('#vback')); await waitFor(() => ui.q('#sall'), 'back');
  ui.click(ui.q('#sall')); await waitFor(() => ui.qa('tbody tr, table tr').length > 150, 'all countries');
  // Grant drill-down and filter
  await ui.goto(3, 'Grant Management');
  ui.click(ui.q('[data-gview="NHMRC"]'));
  await waitFor(() => ui.text().includes('NHMRC: funding and spending'), 'grant detail');
  assert.equal(kpi(ui, 'Total Budget Allocated'), '97,500.00');
  ui.click(ui.q('[data-gfilter="NHMRC"]'));
  await waitFor(() => ui.text().includes('Showing NHMRC only'), 'filter chip');
  assert.equal(kpi(ui, 'Total Budget Allocated'), '97,500.00');
  assert.equal(kpi(ui, 'Total Available Funding'), '97,500.00');
  assert.equal(kpi(ui, 'Actual Expenditure Paid'), '8,000.00');
  ui.change(ui.q('#gf'), ''); await waitFor(() => !ui.text().includes('Showing NHMRC only'), 'filter cleared');
  assert.equal(kpi(ui, 'Total Budget Allocated'), '445,584.00');
  // Reporting period switches
  await ui.goto(5, 'Financial Reporting');
  for (const m of ['quarter', 'year', 'month']) { ui.click(ui.q(`[data-rp="${m}"]`)); await waitFor(() => ui.q(`[data-rp="${m}"].on`), m); }
  ui.change(ui.q('#rfy'), 'cal'); await waitFor(() => ui.q('#rfy').value === 'cal', 'cal');
  assert.ok(ui.q('a[href*="/api/reports/period.csv"]'));
  assert.deepEqual(ui.errors, []);
  ui.close();
});

test('add, inline-edit and delete a transaction; totals follow; validation errors are shown', async () => {
  const ui = await openApp();
  await ui.login('editor1', 'editor-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  await ui.goto(6, 'Income');
  ui.click(ui.q('[data-add="exp"]'));
  await waitFor(() => ui.q('.frm[data-kind="exp"]'), 'form');
  // submit blank -> inline error, nothing created
  ui.click(ui.q('[data-submit="exp"]'));
  await waitFor(() => ui.q('.frm .ferr').textContent.length > 0, 'validation message');
  assert.match(ui.q('.frm .ferr').textContent, /grant/i);
  const f = (k) => ui.q(`.frm [data-f="${k}"]`);
  f('date').value = '2026-09-01'; f('g').value = 'PRG00626'; f('c').value = 'Kenya'; f('w').value = 'Seed funding'; f('cat').value = 'Partner disbursement';
  f('ms').value = 'M1'; f('d').value = 'UI test invoice'; f('amt').value = '1000.50'; f('due').value = '2026-10-30';
  ui.click(ui.q('[data-submit="exp"]'));
  await waitFor(() => ui.qa('input[data-k="d"]').some((i) => i.value === 'UI test invoice'), 'new row');
  assert.ok(ui.text().includes('Outstanding 1,000.50 AUD'));
  assert.equal(T.db.prepare("SELECT COUNT(*) AS n FROM transactions WHERE description='UI test invoice'").get().n, 1);
  // inline edit: mark Paid with a payment date
  const row = () => ui.qa('section.card tr').find((r) => [...r.querySelectorAll('input')].some((i) => i.value === 'UI test invoice'));
  ui.change(row().querySelector('select[data-k="st"]'), 'Paid');
  await waitFor(() => row().querySelector('select[data-k="st"]').value === 'Paid', 'status saved');
  ui.change(row().querySelector('input[data-k="pdate"]'), '2026-09-20');
  await waitFor(() => row().querySelector('input[data-k="pdate"]').value === '2026-09-20', 'pdate saved');
  await waitFor(() => ui.text().includes('Paid 58,182.56'), 'paid total updates after save');
  // rejected edit shows the server message and reverts the field
  ui.change(row().querySelector('input[data-k="amt"]'), '-5');
  await waitFor(() => ui.q('#sv').textContent.includes('negative'), 'error toast');
  assert.ok(ui.q('#sv').classList.contains('er'));
  await waitFor(() => row().querySelector('input[data-k="amt"]').value === '1000.5', 'reverted');
  // foreign currency without a rate -> prompt cancelled -> no change
  ui.change(row().querySelector('select[data-k="ccy"]'), 'USD');
  await waitFor(() => row().querySelector('select[data-k="ccy"]').value === 'AUD', 'ccy reverted');
  // delete requires two clicks
  ui.click(row().querySelector('[data-del]'));
  await waitFor(() => row().querySelector('[data-del]').textContent.includes('Confirm'), 'confirm prompt');
  assert.ok(T.db.prepare("SELECT COUNT(*) AS n FROM transactions WHERE description='UI test invoice'").get().n === 1);
  ui.click(row().querySelector('[data-del]'));
  await waitFor(() => !ui.qa('input[data-k="d"]').some((i) => i.value === 'UI test invoice'), 'row removed');
  assert.equal(T.db.prepare("SELECT COUNT(*) AS n FROM transactions WHERE description='UI test invoice'").get().n, 0);
  assert.deepEqual(ui.errors, []);
  ui.close();
});

test('MoU tracker: add a country, set milestone dates, status and follow-up react', async () => {
  const ui = await openApp();
  await ui.login('editor1', 'editor-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  await ui.goto(1, 'MoU and payment tracker');
  ui.click(ui.q('[data-add="mou"]'));
  await waitFor(() => ui.q('.frm[data-kind="mou"]'), 'form');
  const f = (k) => ui.q(`.frm [data-f="${k}"]`);
  assert.ok(![...f('c').options].some((o) => o.value === 'Kenya'), 'countries that already have an MoU are not offered');
  f('c').value = 'Chad'; f('p').value = 'Chad University'; f('em').value = 'chad@example.org'; f('f').value = '10000'; f('g').value = 'DFAT';
  ui.click(ui.q('[data-submit="mou"]'));
  await waitFor(() => ui.qa('select[data-k="c"]').some((s) => s.value === 'Chad'), 'Chad row');
  const row = () => ui.qa('tr').find((r) => { const s = r.querySelector('select[data-k="c"]'); return s && s.value === 'Chad'; });
  ui.change(row().querySelector('input[data-k="due"][data-j="0"]'), '2020-01-01');
  await waitFor(() => row().textContent.includes('Overdue'), 'overdue status');
  assert.ok(row().classList.contains('al'));
  await ui.goto(0, 'Funds and spending');
  await waitFor(() => ui.text().includes('Overdue milestone M1 - Chad') || ui.q('a[href*="Overdue%20milestone%20M1%20-%20Chad"]'), 'follow-up');
  assert.ok(ui.q('a[href^="mailto:chad@example.org"]'), 'notify link built from partner email');
  // confirming deliverables removes it from the follow-up list
  await ui.goto(1, 'MoU and payment tracker');
  ui.change(row().querySelector('select[data-k="conf"][data-j="0"]'), 'Yes');
  await waitFor(() => row().textContent.includes('Approved - ready to pay'), 'approved');
  await ui.goto(0, 'Funds and spending');
  assert.ok(!ui.q('a[href^="mailto:chad@example.org"]'));
  // cleanup
  await ui.goto(1, 'MoU and payment tracker');
  ui.click(row().querySelector('[data-del]')); await waitFor(() => row().querySelector('[data-del]').textContent.includes('Confirm'), 'c');
  ui.click(row().querySelector('[data-del]')); await waitFor(() => !row(), 'removed');
  assert.deepEqual(ui.errors, []);
  ui.close();
});

test('budget lines: add and edit change the dashboard budget', async () => {
  const ui = await openApp();
  await ui.login('editor1', 'editor-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  await ui.goto(8, 'Budget lines');
  ui.click(ui.q('[data-add="bud"]')); await waitFor(() => ui.q('.frm[data-kind="bud"]'), 'form');
  const f = (k) => ui.q(`.frm [data-f="${k}"]`);
  f('g').value = 'DFAT'; f('c').value = 'Kenya'; f('w').value = 'Travel'; f('d').value = 'UI budget line'; f('a').value = '555.55';
  ui.click(ui.q('[data-submit="bud"]'));
  await waitFor(() => ui.qa('input[data-k="d"]').some((i) => i.value === 'UI budget line'), 'new budget row');
  assert.ok(ui.qa('tr.t').at(-1).textContent.includes('446,139.55'));
  const row = () => ui.qa('tr').find((r) => [...r.querySelectorAll('input')].some((i) => i.value === 'UI budget line'));
  ui.change(row().querySelector('input[data-k="a"]'), '600');
  await waitFor(() => ui.qa('tr.t').at(-1).textContent.includes('446,184.00'), 'edited total');
  ui.click(row().querySelector('[data-del]')); await waitFor(() => row().querySelector('[data-del]').textContent.includes('Confirm'), 'c');
  ui.click(row().querySelector('[data-del]')); await waitFor(() => !row(), 'removed');
  assert.ok(ui.qa('tr.t').at(-1).textContent.includes('445,584.00'));
  assert.deepEqual(ui.errors, []);
  ui.close();
});

test('viewer is read-only; non-admin cannot configure', async () => {
  const ui = await openApp();
  await ui.login('viewer1', 'viewer-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  await ui.goto(6, 'Income');
  assert.equal(ui.qa('[data-add]').length, 0, 'no add buttons');
  assert.equal(ui.qa('[data-del]').length, 0, 'no delete buttons');
  const inputs = ui.qa('table input, table select');
  assert.ok(inputs.length > 20 && inputs.every((i) => i.disabled), 'all table inputs disabled');
  await ui.goto(1, 'MoU and payment tracker');
  assert.equal(ui.qa('[data-add]').length, 0);
  await ui.goto(6, 'Income');
  assert.ok(ui.q('a[href="/api/export/transactions.csv"]'), 'exports are still available');
  await ui.goto(7, 'Only administrators');
  assert.equal(ui.qa('[data-lkadd]').length, 0);
  ui.close();
});

test('admin configuration: rename propagates, protected items, users and audit log', async () => {
  const ui = await openApp();
  await ui.login('admin1', 'admin-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  await ui.goto(7, 'Audit log');
  assert.ok(ui.q('[data-lk="works"][data-old="Salary"]').disabled, 'reserved item locked');
  assert.ok(ui.q('[data-lkdel="countries"][data-name="Global"]').disabled);
  // add + rename a grant
  ui.q('#lkn-grants').value = 'UI Grant'; ui.click(ui.q('[data-lkadd="grants"]'));
  await waitFor(() => ui.q('[data-lk="grants"][data-old="UI Grant"]'), 'grant added');
  ui.change(ui.q('[data-lk="grants"][data-old="UI Grant"]'), 'UI Grant Renamed');
  await waitFor(() => ui.q('[data-lk="grants"][data-old="UI Grant Renamed"]'), 'renamed');
  // removing an in-use grant is refused with a clear message
  ui.click(ui.q('[data-lkdel="grants"][data-name="NHMRC"]'));
  await waitFor(() => ui.q('#sv').textContent.includes('used by'), 'in-use message');
  ui.click(ui.q('[data-lkdel="grants"][data-name="UI Grant Renamed"]'));
  await waitFor(() => !ui.q('[data-lk="grants"][data-old="UI Grant Renamed"]'), 'removed');
  // milestone shares not summing to 100 warn
  const pcts = ui.qa('[data-pct]'); pcts[2].value = '50'; ui.change(pcts[2]);
  await waitFor(() => ui.q('.warn') && ui.q('.warn').textContent.includes('100%'), 'warning');
  ui.qa('[data-pct]')[2].value = '40'; ui.change(ui.qa('[data-pct]')[2]);
  await waitFor(() => ui.qa('[data-pct]')[2].value === '40', 'restored');
  // add a user; audit log lists the changes
  const form = ui.q('.frm [data-uadd]').closest('.frm');
  form.querySelector('[data-f="username"]').value = 'uiuser'; form.querySelector('[data-f="password"]').value = 'ui-user-password'; form.querySelector('[data-f="role"]').value = 'editor';
  ui.click(ui.q('[data-uadd]'));
  await waitFor(() => ui.text().includes('uiuser'), 'user listed');
  assert.ok(ui.text().includes('create') && ui.text().includes('lookup'));
  assert.deepEqual(ui.errors, []);
  ui.close();
});

test('XSS: hostile text in data is rendered inert everywhere', async () => {
  const evil = '<img src=x onerror="window.__pwned=1"><script>window.__pwned=2</script>';
  const admin = await T.as('admin');
  const t = await admin.post('/api/transactions', { type: 'Expenditure', g: 'PRG00626', c: 'Kenya', w: 'Seed funding', cat: 'Partner disbursement', d: evil, doc: evil, amt: 5, ccy: 'AUD', st: 'Paid', date: '2026-01-01', staff: evil });
  const b = await admin.post('/api/budget', { g: 'PRG00626', c: 'Kenya', w: 'Seed funding', d: evil, a: 1 });
  const m = await admin.post('/api/mous', { c: 'Chad', p: evil, em: 'x@y.org', f: 100, due: ['2020-01-01', '', ''], conf: ['', '', ''], act: evil, who: evil });
  assert.equal(t.status, 201); assert.equal(b.status, 201); assert.equal(m.status, 201);
  const ui = await openApp();
  await ui.login('admin1', 'admin-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  for (const i of [0, 1, 2, 3, 4, 5, 6, 8, 7]) await ui.goto(i, '');
  ui.click(ui.q('#nav [data-tab="0"]'));
  ui.click(ui.q('#nav [data-tab="1"]'));
  await ui.goto(2, 'Country Financials');
  assert.equal(ui.w.__pwned, undefined, 'no script executed');
  assert.equal(ui.qa('img[src="x"]').length, 0, 'no injected <img>');
  assert.equal(ui.qa('main script').length, 0);
  await ui.goto(6, 'Income');
  assert.ok([...ui.qa('input')].some((i) => i.value === evil), 'value is shown as plain text in inputs');
  ui.close();
  await admin.del('/api/transactions/' + t.json.id); await admin.del('/api/budget/' + b.json.id); await admin.del('/api/mous/' + m.json.id);
});

test('sign out returns to the login screen and the session is gone', async () => {
  const ui = await openApp();
  await ui.login('editor1', 'editor-password-1');
  await waitFor(() => kpi(ui, 'Total Budget Allocated'), 'dashboard');
  ui.click(ui.q('#logout'));
  await waitFor(() => ui.q('.login'), 'login screen');
  const me = await (await ui.w.fetch('/api/auth/me')).json();
  assert.equal(me.user, null);
  assert.equal(ui.q('#nav').children.length, 0);
  ui.close();
});
