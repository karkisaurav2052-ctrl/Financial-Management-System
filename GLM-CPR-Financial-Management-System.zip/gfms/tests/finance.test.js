'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../shared/finance');

const base = () => ({
  rep: 'AUD', pct: [0.3, 0.3, 0.4], cpa: null, gf: '',
  L: { grants: ['G1', 'G2'], countries: ['Global', 'Kenya', 'India'], works: ['Salary', 'Seed funding'], cats: ['Partner disbursement', 'Salary'], ccys: ['AUD', 'USD'] },
  bud: [], reg: [], trk: [],
});
const exp = (o) => ({ type: 'Expenditure', date: '', g: 'G1', c: 'Kenya', w: 'Seed funding', cat: 'Partner disbursement', ms: '', d: '', ccy: 'AUD', amt: 0, fx: '', st: 'Paid', due: '', pdate: '', doc: '', ver: 'No', staff: '', ...o });
const inc = (o) => ({ type: 'Income', date: '', g: 'G1', c: 'Global', w: '', cat: '', ms: '', d: '', ccy: 'AUD', amt: 0, fx: '', st: 'Available', due: '', pdate: '', doc: '', ver: 'No', staff: '', ...o });
const mou = (o) => ({ c: 'Kenya', p: '', em: '', g: 'G1', s: '', e: '', f: 10000, due: ['', '', ''], conf: ['', '', ''], act: '', who: '', ...o });

test('toC: float-safe cents', () => {
  assert.equal(F.toC(0.1 + 0.2), 30);
  assert.equal(F.toC(1500.6), 150060);
  assert.equal(F.toC(''), 0);
  assert.equal(F.toC(null), 0);
  assert.equal(F.toC('abc'), 0);
  assert.equal(F.toC(-12.34), -1234);
});

test('rowC / RA: reporting currency and FX', () => {
  assert.equal(F.RA({ ccy: 'AUD', amt: 100.25 }, 'AUD'), 100.25);
  assert.equal(F.RA({ ccy: 'USD', amt: 100, fx: 1.5 }, 'AUD'), 150);
  assert.equal(F.RA({ ccy: 'USD', amt: 100, fx: '' }, 'AUD'), 0, 'foreign without FX counts as 0');
  assert.equal(F.RA({ ccy: 'USD', amt: 33.33, fx: 1.4567 }, 'AUD'), 48.55); // 3333*1.4567=4855.0 -> rounded per row
  assert.equal(F.RA({ ccy: 'AUD', amt: '' }, 'AUD'), 0);
});

test('dd: whole days, sign, blank, month/year boundaries', () => {
  assert.equal(F.dd('2026-10-25', '2026-10-25'), 0);
  assert.equal(F.dd('2026-10-26', '2026-10-25'), 1);
  assert.equal(F.dd('2026-10-24', '2026-10-25'), -1);
  assert.equal(F.dd('2027-01-01', '2026-12-31'), 1);
  assert.equal(F.dd('2026-04-05', '2026-03-29'), 7); // DST-safe (UTC arithmetic)
  assert.equal(F.dd('', '2026-10-25'), null);
});

test('totals respect the grant filter', () => {
  const S = base();
  S.bud = [{ g: 'G1', c: 'Kenya', w: 'Seed funding', d: '', a: 1000 }, { g: 'G2', c: 'Kenya', w: 'Seed funding', d: '', a: 500.5 }];
  S.reg = [inc({ g: 'G1', amt: 2000 }), inc({ g: 'G2', amt: 700 }), exp({ g: 'G1', amt: 100 }), exp({ g: 'G2', amt: 40.4 }), exp({ g: 'G2', amt: 9.6, st: 'Outstanding' })];
  assert.equal(F.totalBudget(S), 1500.5);
  assert.equal(F.incomeTotal(S), 2700);
  assert.equal(F.paidTotal(S), 140.4);
  assert.equal(F.outTotal(S), 9.6);
  S.gf = 'G2';
  assert.equal(F.totalBudget(S), 500.5);
  assert.equal(F.incomeTotal(S), 700);
  assert.equal(F.paidTotal(S), 40.4);
  assert.equal(F.paidBy(S, 'c', 'Kenya'), 40.4);
  assert.equal(F.budBy(S, 'c', 'Kenya'), 500.5);
  const d = F.dashboard(S, '2026-01-01');
  assert.equal(d.remaining, 460.1);
  assert.equal(d.surplus, 199.5);
  assert.ok(Math.abs(d.utilisationPct - (40.4 / 500.5) * 100) < 1e-9);
});

test('grantSummary ignores the grant filter and totals add up', () => {
  const S = base();
  S.gf = 'G1';
  S.bud = [{ g: 'G1', c: 'Kenya', w: 'Seed funding', d: '', a: 1000 }, { g: 'G2', c: 'India', w: 'Seed funding', d: '', a: 400 }];
  S.reg = [inc({ g: 'G1', amt: 1500 }), inc({ g: 'G2', amt: 300 }), exp({ g: 'G1', amt: 250 }), exp({ g: 'G2', amt: 50, st: 'Outstanding' })];
  const r = F.grantSummary(S);
  assert.deepEqual(r.rows.map((x) => [x.g, x.a, x.b, x.p, x.o, x.remaining, x.surplus]), [['G1', 1500, 1000, 250, 0, 750, 500], ['G2', 300, 400, 0, 50, 350, -100]]);
  assert.deepEqual(r.total, { a: 1800, b: 1400, p: 250, o: 50, remaining: 1100, surplus: 400 });
});

test('milestone status machine', () => {
  const S = base();
  const t = mou({ f: 10000, due: ['2026-11-10', '2026-09-01', ''], conf: ['', '', ''] });
  S.trk = [t];
  const today = '2026-10-25';
  assert.equal(F.milestoneAmountC(S, t, 0), 300000);
  assert.equal(F.milestoneStatus(S, t, 0, today), 'Awaiting deliverable');
  assert.equal(F.milestoneStatus(S, t, 1, today), 'Overdue');
  assert.equal(F.milestoneStatus(S, t, 2, today), 'Not scheduled');
  t.conf[0] = 'Yes';
  assert.equal(F.milestoneStatus(S, t, 0, today), 'Approved - ready to pay');
  S.reg = [exp({ amt: 1000, ms: 'M1' })];
  assert.equal(F.milestoneStatus(S, t, 0, today), 'Part-paid');
  S.reg.push(exp({ amt: 2000, ms: 'M1' }));
  assert.equal(F.milestoneStatus(S, t, 0, today), 'Paid');
  // outstanding invoices and non-disbursement categories do not count as paid
  S.reg = [exp({ amt: 3000, ms: 'M1', st: 'Outstanding' }), exp({ amt: 3000, ms: 'M1', cat: 'Salary' })];
  assert.equal(F.milestoneStatus(S, t, 0, today), 'Approved - ready to pay');
  t.f = 0;
  assert.equal(F.milestoneStatus(S, t, 0, today), '', 'no agreed funding => no milestone status');
});

test('upcomingPayments, followUps, mouSchedule', () => {
  const S = base();
  S.trk = [
    mou({ c: 'Kenya', f: 10000, due: ['2026-10-20', '2026-11-01', ''] }),
    mou({ c: 'India', g: 'G2', f: 5000, due: ['2026-10-10', '', ''], conf: ['Yes', '', ''] }),
  ];
  const today = '2026-10-25';
  const P = F.upcomingPayments(S, today);
  assert.deepEqual(P.map((p) => [p.c, p.m, p.n, p.s]), [['India', 'M1', -15, 'Approved - ready to pay'], ['Kenya', 'M1', -5, 'Overdue'], ['Kenya', 'M2', 7, 'Awaiting deliverable']]);
  assert.deepEqual(F.followUps(S, today).map((p) => p.c), ['Kenya'], 'confirmed deliverables are not chased');
  S.gf = 'G2';
  assert.deepEqual(F.upcomingPayments(S, today).map((p) => p.c), ['India']);
  S.gf = '';
  const sch = F.mouSchedule(S, today);
  assert.equal(sch.find((x) => x.c === 'Kenya').status, 'Overdue');
  assert.equal(sch.find((x) => x.c === 'Kenya').outstanding, 10000);
  S.reg = [exp({ c: 'India', g: 'G2', amt: 5000 })];
  assert.equal(F.mouSchedule(S, today).find((x) => x.c === 'India').status, 'Completed');
  assert.equal(F.dashboard(S, today).mouOutstanding, 10000);
});

test('outstandingDue: 28-day window and undated invoices', () => {
  const S = base();
  S.reg = [exp({ st: 'Outstanding', amt: 1, due: '2026-10-20', d: 'late' }), exp({ st: 'Outstanding', amt: 2, due: '2026-11-22', d: 'edge28' }),
    exp({ st: 'Outstanding', amt: 3, due: '2026-11-23', d: 'edge29' }), exp({ st: 'Outstanding', amt: 4, d: 'nodue' }), exp({ st: 'Paid', amt: 5, due: '2026-10-26' })];
  const o = F.outstandingDue(S, '2026-10-25');
  assert.deepEqual(o.rows.map((r) => r.d), ['late', 'edge28']);
  assert.equal(o.noDue, 1);
});

test('periodKey: calendar and financial-year labels', () => {
  assert.deepEqual(F.periodKey('2026-07-01', 'year', true), { k: '2027', l: 'FY2027 (Jul 2026 to Jun 2027)' });
  assert.deepEqual(F.periodKey('2026-06-30', 'year', true), { k: '2026', l: 'FY2026 (Jul 2025 to Jun 2026)' });
  assert.deepEqual(F.periodKey('2026-07-15', 'quarter', true), { k: '2027-Q1', l: 'FY2027 Q1' });
  assert.deepEqual(F.periodKey('2026-06-15', 'quarter', true), { k: '2026-Q4', l: 'FY2026 Q4' });
  assert.deepEqual(F.periodKey('2026-01-15', 'quarter', true), { k: '2026-Q3', l: 'FY2026 Q3' });
  assert.deepEqual(F.periodKey('2026-01-15', 'quarter', false), { k: '2026-Q1', l: '2026 Q1' });
  assert.deepEqual(F.periodKey('2026-12-31', 'quarter', false), { k: '2026-Q4', l: '2026 Q4' });
  assert.deepEqual(F.periodKey('2026-03-09', 'month', true), { k: '2026-03', l: 'Mar 2026' });
  assert.equal(F.periodKey('', 'month', true), null);
});

test('periodReport: dating rules, cumulative, undated bucket, workstream matrix', () => {
  const S = base();
  S.reg = [
    inc({ date: '2026-07-10', amt: 1000 }),
    exp({ date: '2026-07-01', pdate: '2026-08-05', amt: 300, w: 'Seed funding' }),   // paid -> payment date (Aug)
    exp({ date: '2026-07-20', amt: 100, w: 'Salary' }),                                // paid, no pdate -> invoice date (Jul)
    exp({ date: '2026-07-25', amt: 50, st: 'Outstanding' }),                           // outstanding -> invoice date
    exp({ amt: 20, w: 'Salary' }),                                                     // undated opening balance
  ];
  const r = F.periodReport(S, 'month', true);
  assert.deepEqual(r.labels, ['Undated (opening balances)', 'Jul 2026', 'Aug 2026']);
  assert.deepEqual(r.rows.map((x) => [x.income, x.paid, x.outstanding, x.net, x.cumulative]), [[0, 20, 0, -20, -20], [1000, 100, 50, 900, 880], [0, 300, 0, -300, 580]]);
  assert.deepEqual(r.total, { income: 1000, paid: 420, outstanding: 50, net: 580, cumulative: 580 });
  assert.deepEqual(r.matrix.map((m) => [m.workstream, m.cells, m.total]), [['Salary', [20, 100, 0], 120], ['Seed funding', [0, 0, 300], 300]]);
  assert.deepEqual(r.matrixTotals, [20, 100, 300]);
  const y = F.periodReport(S, 'year', true);
  assert.deepEqual(y.rows.map((x) => x.key), ['~', '2027']);
  assert.equal(y.rows[1].paid, 400);
  assert.match(F.periodCsv(r), /^"Period","Income"/);
  assert.equal(F.periodReport({ ...base() }, 'month', true).rows.length, 0);
});

test('groupSummary: countries hide empty rows; salary breakdown reconciles', () => {
  const S = base();
  S.bud = [{ g: 'G1', c: 'Global', w: 'Salary', d: 'Salary - Ann', a: 1000, staff: 'Ann' }, { g: 'G1', c: 'Global', w: 'Salary', d: 'Salary - Bob', a: 500, staff: 'Bob' },
    { g: 'G1', c: 'Global', w: 'Salary', d: 'unallocated', a: 1, staff: '' }, { g: 'G1', c: 'Kenya', w: 'Seed funding', d: '', a: 200 }];
  S.reg = [exp({ c: 'Global', w: 'Salary', cat: 'Salary', amt: 300, staff: 'Ann' }), exp({ c: 'Global', w: 'Salary', cat: 'Salary', amt: 70, staff: 'Bob', st: 'Outstanding' }), exp({ c: 'Global', w: 'Salary', cat: 'Salary', amt: 5 })];
  const w = F.groupSummary(S, 'w');
  const sal = w.rows.find((r) => r.name === 'Salary');
  assert.deepEqual([sal.b, sal.p, sal.c, sal.rem, sal.pct], [1501, 305, 70, 1126, 25]);
  assert.deepEqual(sal.sub.map((x) => [x.name, x.b, x.p, x.c, x.rem]), [['Ann', 1000, 300, 0, 700], ['Bob', 500, 0, 70, 430], ['Other / unallocated', 1, 5, 0, -4]]);
  assert.equal(sal.sub.reduce((a, x) => a + x.b, 0), sal.b);
  const c = F.groupSummary(S, 'c', false);
  assert.deepEqual(c.rows.map((r) => r.name), ['Global', 'Kenya'], 'India has no activity => hidden');
  assert.equal(F.groupSummary(S, 'c', true).rows.length, 3);
  assert.deepEqual(c.total, { b: 1701, p: 305, c: 70, rem: 1326, pct: 22 });
});

test('reconciliation: detects orphans, missing FX/doc, bad shares, CPA', () => {
  const S = base();
  S.reg = [exp({ amt: 100, doc: 'INV1', ver: 'Yes' }), exp({ amt: 50 })];
  let r = F.reconciliation(S);
  assert.ok(r.checks.every((c) => c.id === 'docs' ? !c.ok : c.ok));
  assert.equal(r.unverified.n, 1);
  S.reg.push(exp({ amt: 10, c: '', doc: 'x' }), exp({ amt: 10, w: '', doc: 'y' }), exp({ amt: 10, ccy: 'USD', fx: '', doc: 'z' }));
  r = F.reconciliation(S);
  const by = Object.fromEntries(r.checks.map((c) => [c.id, c]));
  assert.equal(by.country.ok, false); assert.equal(by.country.detail, -10);
  assert.equal(by.workstream.ok, false); assert.equal(by.fx.ok, false);
  S.pct = [0.3, 0.3, 0.3];
  assert.equal(F.reconciliation(S).checks.find((c) => c.id === 'shares').ok, false);
  S.cpa = 170;
  assert.deepEqual(F.reconciliation(S).cpa, { cpa: 170, diff: 0, ok: true });
  S.cpa = 169.5;
  assert.equal(F.reconciliation(S).cpa.diff, 0.5);
});

test('csv: spreadsheet-formula injection is neutralised', () => {
  assert.equal(F.csvCell('=1+1'), '"\'=1+1"');
  assert.equal(F.csvCell('@SUM(A1)'), '"\'@SUM(A1)"');
  assert.equal(F.csvCell('+cmd'), '"\'+cmd"');
  assert.equal(F.csvCell('-5'), '"-5"');
  assert.equal(F.csvCell('-cmd|x'), '"\'-cmd|x"');
  assert.equal(F.csvCell('say "hi"'), '"say ""hi"""');
  assert.equal(F.csvCell(null), '""');
  assert.equal(F.toCsv([['a', 1], ['b', 2]]), '"a","1"\r\n"b","2"\r\n');
});

test('breakdown: drill-down by country within a grant, by workstream within a country', () => {
  const S = base();
  S.bud = [{ g: 'G1', c: 'Kenya', w: 'Seed funding', d: '', a: 100 }, { g: 'G1', c: 'India', w: 'Seed funding', d: '', a: 50 }, { g: 'G2', c: 'Kenya', w: 'Salary', d: '', a: 7 }];
  S.reg = [exp({ g: 'G1', c: 'Kenya', amt: 30 }), exp({ g: 'G1', c: 'Kenya', amt: 5, st: 'Outstanding' }), exp({ g: 'G1', c: 'Global', amt: 2 }), exp({ g: 'G2', c: 'Kenya', w: 'Salary', amt: 1 }), inc({ g: 'G1', amt: 999 })];
  assert.deepEqual(F.breakdown(S, 'g', 'G1', 'c'), [
    { name: 'Global', b: 0, p: 2, o: 0, rem: -2 }, { name: 'India', b: 50, p: 0, o: 0, rem: 50 }, { name: 'Kenya', b: 100, p: 30, o: 5, rem: 65 }]);
  assert.deepEqual(F.breakdown(S, 'c', 'Kenya', 'w'), [{ name: 'Salary', b: 7, p: 1, o: 0, rem: 6 }, { name: 'Seed funding', b: 100, p: 30, o: 5, rem: 65 }]);
  S.gf = 'G1';
  assert.deepEqual(F.breakdown(S, 'c', 'Kenya', 'w').map((x) => x.name), ['Seed funding'], 'respects the grant filter');
});
