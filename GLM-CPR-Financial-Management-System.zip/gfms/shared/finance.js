/*
 * Finance core: every number shown in the system is computed here.
 * Used by the browser (window.Finance) and by the server + tests (require).
 * All money is summed in integer cents and returned as decimals.
 *
 * State shape (S):
 *   rep   reporting currency code            pct  [m1,m2,m3] fractions
 *   cpa   CPA statement total | null          gf   grant filter ('' = all)
 *   L     { grants, countries, works, cats, ccys }   (countries[0] is the bucket, e.g. 'Global')
 *   bud   [{ g, c, w, d, a, staff }]
 *   reg   [{ type, date, g, c, w, cat, ms, d, ccy, amt, fx, st, due, pdate, doc, ver, staff }]
 *   trk   [{ c, p, em, g, s, e, f, due:[3], conf:[3], act, who }]
 *
 * `today` is always an ISO 'YYYY-MM-DD' string so results are deterministic.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Finance = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const TOL_C = 50; // 0.50 tolerance when deciding "paid in full" (rounding of milestone splits)
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  // ---------- primitives ------------------------------------------------
  const toC = (x) => {
    const n = Number(x);
    if (x === '' || x == null || !Number.isFinite(n)) return 0;
    return Math.round((n + (n >= 0 ? 1 : -1) * Number.EPSILON * Math.abs(n)) * 100);
  };
  const fromC = (c) => c / 100;
  const isBlank = (v) => v === '' || v == null;

  /** Row amount in reporting currency, integer cents. Foreign rows without an FX rate count as 0. */
  const rowC = (r, rep) => {
    if (isBlank(r.amt)) return 0;
    if (r.ccy === rep) return toC(r.amt);
    const fx = Number(r.fx);
    return fx > 0 ? Math.round(toC(r.amt) * fx) : 0;
  };
  const RA = (r, rep) => fromC(rowC(r, rep));

  const dayNum = (s) => Date.parse(s + 'T00:00:00Z') / 864e5;
  /** Whole days from `today` to `s`; null when s is blank. Negative = in the past. */
  const dd = (s, today) => (s ? Math.round(dayNum(s) - dayNum(today)) : null);

  // ---------- filtered sums --------------------------------------------
  const regF = (S) => S.reg.filter((r) => !S.gf || r.g === S.gf);
  const budF = (S) => S.bud.filter((b) => !S.gf || b.g === S.gf);
  const sumRegC = (S, pred) => regF(S).filter(pred).reduce((a, r) => a + rowC(r, S.rep), 0);
  const sumRegAllC = (S, pred) => S.reg.filter(pred).reduce((a, r) => a + rowC(r, S.rep), 0); // ignores grant filter
  const sumBudC = (S, pred) => S.bud.filter(pred).reduce((a, b) => a + toC(b.a), 0);

  const isPaidExp = (r) => r.type === 'Expenditure' && r.st === 'Paid';
  const isOutExp = (r) => r.type === 'Expenditure' && r.st === 'Outstanding';

  const paidBy = (S, k, v) => fromC(sumRegC(S, (r) => isPaidExp(r) && r[k] === v));
  const outBy = (S, k, v) => fromC(sumRegC(S, (r) => isOutExp(r) && r[k] === v));
  const budBy = (S, k, v) => fromC(sumBudC(S, (b) => (!S.gf || b.g === S.gf) && b[k] === v));
  const totalBudget = (S) => fromC(sumBudC(S, (b) => !S.gf || b.g === S.gf));
  const incomeTotal = (S) => fromC(sumRegC(S, (r) => r.type === 'Income'));
  const paidTotal = (S) => fromC(sumRegC(S, isPaidExp));
  const outTotal = (S) => fromC(sumRegC(S, isOutExp));

  /** Partner disbursements paid to a country (optionally for milestone index k = 0..2). */
  const disbursedC = (S, country, k) =>
    sumRegC(S, (r) => isPaidExp(r) && r.cat === 'Partner disbursement' && r.c === country && (k == null || r.ms === 'M' + (k + 1)));
  const disbursed = (S, country, k) => fromC(disbursedC(S, country, k));

  // ---------- MoU milestones -------------------------------------------
  const milestoneAmountC = (S, t, k) => Math.round(toC(t.f) * (S.pct[k] || 0));
  function milestoneStatus(S, t, k, today) {
    const a = milestoneAmountC(S, t, k);
    if (!a) return '';
    const p = disbursedC(S, t.c, k);
    if (p >= a - TOL_C) return 'Paid';
    if (t.conf[k] === 'Yes') return p > 0 ? 'Part-paid' : 'Approved - ready to pay';
    if (!t.due[k]) return 'Not scheduled';
    return dd(t.due[k], today) < 0 ? 'Overdue' : 'Awaiting deliverable';
  }

  /** All unpaid scheduled milestones, soonest first. */
  function upcomingPayments(S, today) {
    const out = [];
    S.trk.forEach((t) => {
      if (!t.c || (S.gf && t.g !== S.gf)) return;
      for (let k = 0; k < 3; k++) {
        const s = milestoneStatus(S, t, k, today);
        if (t.due[k] && s && s !== 'Paid') {
          out.push({ c: t.c, m: 'M' + (k + 1), a: fromC(milestoneAmountC(S, t, k)), d: t.due[k], n: dd(t.due[k], today), s, cf: t.conf[k], em: t.em || '', p: t.p || '' });
        }
      }
    });
    return out.sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : 0));
  }

  /** Overdue milestones whose deliverables are not confirmed (drives the partner follow-up emails). */
  const followUps = (S, today) => upcomingPayments(S, today).filter((p) => p.n < 0 && p.cf !== 'Yes');

  /** Outstanding invoices due within `days` (default 28) plus a count of those with no due date. */
  function outstandingDue(S, today, days) {
    const lim = days == null ? 28 : days;
    const L = regF(S).filter(isOutExp).map((r) => ({ ...r, n: dd(r.due, today), amount: RA(r, S.rep) }));
    return {
      noDue: L.filter((r) => r.n == null).length,
      rows: L.filter((r) => r.n != null && r.n <= lim).sort((a, b) => a.n - b.n),
    };
  }

  // ---------- dashboard -------------------------------------------------
  function dashboard(S, today) {
    const av = incomeTotal(S), pa = paidTotal(S), co = outTotal(S), b = totalBudget(S);
    const P = upcomingPayments(S, today);
    const ov = P.filter((p) => p.n < 0), nx = P.filter((p) => p.n >= 0 && p.n <= 28);
    const sumA = (L) => fromC(L.reduce((a, p) => a + toC(p.a), 0));
    const mouOut = S.trk.reduce((a, t) => a + (t.c && (!S.gf || t.g === S.gf) ? toC(t.f) - disbursedC(S, t.c) : 0), 0);
    return {
      available: av, budget: b, paid: pa, outstanding: co,
      remaining: fromC(toC(b) - toC(pa)), surplus: fromC(toC(av) - toC(b)),
      utilisationPct: b > 0 ? (pa / b) * 100 : 0,
      overdue: { n: ov.length, amount: sumA(ov) }, next28: { n: nx.length, amount: sumA(nx) },
      mouOutstanding: fromC(mouOut),
    };
  }

  /** MoU payment schedule table. */
  function mouSchedule(S, today) {
    return S.trk.filter((t) => t.c && +t.f && (!S.gf || t.g === S.gf)).map((t) => {
      const pv = disbursedC(S, t.c), o = toC(t.f) - pv;
      const ds = [0, 1, 2].filter((k) => t.due[k] && milestoneStatus(S, t, k, today) !== 'Paid').map((k) => t.due[k]).sort()[0] || '';
      const n = ds ? dd(ds, today) : null;
      const st = o <= TOL_C ? 'Completed' : n != null && n < 0 ? 'Overdue' : n != null && n <= 28 ? 'Due soon' : ds ? 'Scheduled' : 'Not scheduled';
      return { c: t.c, p: t.p, total: +t.f, paid: fromC(pv), outstanding: fromC(o), next: ds, status: st };
    });
  }

  // ---------- grant / country / workstream summaries ---------------------
  /** Per-grant numbers; intentionally ignores the grant filter (the grants table lists every grant). */
  function grantNums(S, g) {
    const a = sumRegAllC(S, (r) => r.g === g && r.type === 'Income');
    const b = sumBudC(S, (x) => x.g === g);
    const p = sumRegAllC(S, (r) => r.g === g && isPaidExp(r));
    const o = sumRegAllC(S, (r) => r.g === g && isOutExp(r));
    return { a: fromC(a), b: fromC(b), p: fromC(p), o: fromC(o), remaining: fromC(b - p - o), surplus: fromC(a - b) };
  }
  function grantSummary(S) {
    const T = { a: 0, b: 0, p: 0, o: 0 };
    const rows = S.L.grants.map((g) => {
      const n = grantNums(S, g);
      T.a += toC(n.a); T.b += toC(n.b); T.p += toC(n.p); T.o += toC(n.o);
      return { g, ...n };
    });
    return { rows, total: { a: fromC(T.a), b: fromC(T.b), p: fromC(T.p), o: fromC(T.o), remaining: fromC(T.b - T.p - T.o), surplus: fromC(T.a - T.b) } };
  }

  const pctUsed = (b, p, c) => (b ? Math.round(((p + c) / b) * 100) : null);

  /** Salary split by staff member; anything not tagged goes to 'Other / unallocated'. */
  function salaryBreakdown(S, B, P, C) {
    const names = [...new Set([...budF(S).filter((x) => x.w === 'Salary' && x.staff).map((x) => x.staff),
      ...regF(S).filter((r) => r.w === 'Salary' && r.type === 'Expenditure' && r.staff).map((r) => r.staff)])].sort();
    let sb = 0, sp = 0, sc = 0;
    const rows = names.map((n) => {
      const b = budF(S).filter((x) => x.w === 'Salary' && x.staff === n).reduce((a, x) => a + toC(x.a), 0);
      const m = regF(S).filter((r) => r.w === 'Salary' && r.type === 'Expenditure' && r.staff === n);
      const p = m.filter((r) => r.st === 'Paid').reduce((a, r) => a + rowC(r, S.rep), 0);
      const c = m.filter((r) => r.st === 'Outstanding').reduce((a, r) => a + rowC(r, S.rep), 0);
      sb += b; sp += p; sc += c;
      return { name: n, b: fromC(b), p: fromC(p), c: fromC(c), rem: fromC(b - p - c), pct: pctUsed(fromC(b), fromC(p), fromC(c)) };
    });
    const ob = toC(B) - sb, op = toC(P) - sp, oc = toC(C) - sc;
    rows.push({ name: 'Other / unallocated', b: fromC(ob), p: fromC(op), c: fromC(oc), rem: fromC(ob - op - oc), pct: pctUsed(fromC(ob), fromC(op), fromC(oc)) });
    return rows;
  }

  /**
   * Country or Workstream table. key 'c'|'w'. Countries with no activity are hidden unless showAll.
   * The Salary workstream carries a per-person breakdown in `sub`.
   */
  function groupSummary(S, key, showAll) {
    const list = key === 'c' ? S.L.countries : S.L.works;
    let tb = 0, tp = 0, tc = 0;
    const rows = [];
    list.forEach((n) => {
      const b = budBy(S, key, n), p = paidBy(S, key, n), c = outBy(S, key, n);
      if (key === 'c' && !showAll && !b && !p && !c) return;
      tb += toC(b); tp += toC(p); tc += toC(c);
      rows.push({ name: n, b, p, c, rem: fromC(toC(b) - toC(p) - toC(c)), pct: pctUsed(b, p, c), sub: key === 'w' && n === 'Salary' ? salaryBreakdown(S, b, p, c) : null });
    });
    return { rows, total: { b: fromC(tb), p: fromC(tp), c: fromC(tc), rem: fromC(tb - tp - tc), pct: pctUsed(fromC(tb), fromC(tp), fromC(tc)) } };
  }

  /** Detail view for one country (or one grant when key === 'g'). */
  function detail(S, key, value) {
    const inScope = (x) => x[key] === value;
    const b = fromC(sumBudC(S, (x) => (!S.gf || x.g === S.gf) && inScope(x)));
    const p = fromC(sumRegC(S, (r) => isPaidExp(r) && inScope(r)));
    const o = fromC(sumRegC(S, (r) => isOutExp(r) && inScope(r)));
    return { b, p, o, remaining: fromC(toC(b) - toC(p) - toC(o)) };
  }

  /** Drill-down: for rows where scopeKey===scopeVal, budget / paid / outstanding grouped by groupKey ('c' | 'w'). */
  function breakdown(S, scopeKey, scopeVal, groupKey) {
    const bud = budF(S).filter((x) => x[scopeKey] === scopeVal);
    const reg = regF(S).filter((r) => r.type === 'Expenditure' && r[scopeKey] === scopeVal);
    const keys = [...new Set([...bud.map((x) => x[groupKey]), ...reg.map((r) => r[groupKey])])].filter(Boolean).sort((a, b) => a.localeCompare(b));
    return keys.map((n) => {
      const b = bud.filter((x) => x[groupKey] === n).reduce((a, x) => a + toC(x.a), 0);
      const p = reg.filter((r) => r[groupKey] === n && r.st === 'Paid').reduce((a, r) => a + rowC(r, S.rep), 0);
      const o = reg.filter((r) => r[groupKey] === n && r.st === 'Outstanding').reduce((a, r) => a + rowC(r, S.rep), 0);
      return { name: n, b: fromC(b), p: fromC(p), o: fromC(o), rem: fromC(b - p - o) };
    });
  }

  // ---------- reporting periods ------------------------------------------
  function periodKey(d, mode, fy) {
    if (!d) return null;
    const y = +d.slice(0, 4), m = +d.slice(5, 7), fyr = m >= 7 ? y + 1 : y;
    if (mode === 'month') return { k: d.slice(0, 7), l: MONTHS[m - 1] + ' ' + y };
    if (mode === 'quarter') {
      const q = fy ? Math.floor(((m + 5) % 12) / 3) + 1 : Math.floor((m - 1) / 3) + 1, Y = fy ? fyr : y;
      return { k: Y + '-Q' + q, l: (fy ? 'FY' : '') + Y + ' Q' + q };
    }
    return fy ? { k: '' + fyr, l: 'FY' + fyr + ' (Jul ' + (fyr - 1) + ' to Jun ' + fyr + ')' } : { k: '' + y, l: '' + y };
  }

  function periodReport(S, mode, fy) {
    mode = mode || 'month';
    fy = fy !== false;
    const P = new Map();
    const add = (d, kind, c) => {
      const p = periodKey(d, mode, fy), k = p ? p.k : '~';
      if (!P.has(k)) P.set(k, { l: p ? p.l : 'Undated (opening balances)', i: 0, p: 0, o: 0 });
      P.get(k)[kind] += c;
    };
    regF(S).forEach((r) => {
      const c = rowC(r, S.rep);
      if (r.type === 'Income') add(r.date, 'i', c);
      else if (r.st === 'Paid') add(r.pdate || r.date, 'p', c);
      else add(r.date, 'o', c);
    });
    const keys = [...P.keys()].sort((a, b) => (a === '~' ? -1 : b === '~' ? 1 : a < b ? -1 : 1));
    let cum = 0;
    const T = { i: 0, p: 0, o: 0 };
    const rows = keys.map((k) => {
      const x = P.get(k), net = x.i - x.p;
      cum += net; T.i += x.i; T.p += x.p; T.o += x.o;
      return { key: k, label: x.l, income: fromC(x.i), paid: fromC(x.p), outstanding: fromC(x.o), net: fromC(net), cumulative: fromC(cum) };
    });
    // paid expenditure by workstream x period
    const W = new Map();
    regF(S).filter(isPaidExp).forEach((r) => {
      const p = periodKey(r.pdate || r.date, mode, fy), k = p ? p.k : '~', w = r.w || '(no workstream)';
      if (!W.has(w)) W.set(w, {});
      W.get(w)[k] = (W.get(w)[k] || 0) + rowC(r, S.rep);
    });
    const colTotals = {};
    const matrix = [...W.keys()].sort().map((w) => {
      let t = 0;
      const cells = keys.map((k) => { const v = W.get(w)[k] || 0; t += v; colTotals[k] = (colTotals[k] || 0) + v; return fromC(v); });
      return { workstream: w, cells, total: fromC(t) };
    });
    return {
      mode, fy, keys, labels: keys.map((k) => P.get(k).l), rows,
      total: { income: fromC(T.i), paid: fromC(T.p), outstanding: fromC(T.o), net: fromC(T.i - T.p), cumulative: fromC(cum) },
      matrix, matrixTotals: keys.map((k) => fromC(colTotals[k] || 0)),
    };
  }

  // ---------- reconciliation ---------------------------------------------
  function reconciliation(S) {
    const pa = paidTotal(S);
    const sumC = S.L.countries.reduce((a, c) => a + toC(paidBy(S, 'c', c)), 0);
    const sumW = S.L.works.reduce((a, w) => a + toC(paidBy(S, 'w', w)), 0);
    const nofx = S.reg.filter((r) => !isBlank(r.amt) && r.ccy !== S.rep && !(Number(r.fx) > 0)).length;
    const nodoc = S.reg.filter((r) => r.st === 'Paid' && !r.doc).length;
    const unv = S.reg.filter((r) => r.ver !== 'Yes').length;
    const share = S.pct.reduce((a, b) => a + b, 0);
    const checks = [
      { id: 'country', label: 'Country Financials paid = transactions paid', ok: sumC === toC(pa), detail: fromC(sumC - toC(pa)) },
      { id: 'workstream', label: 'Workstream Financials paid = transactions paid', ok: sumW === toC(pa), detail: fromC(sumW - toC(pa)) },
      { id: 'fx', label: 'Foreign-currency rows have an FX rate', ok: !nofx, detail: nofx + ' missing' },
      { id: 'docs', label: 'Paid rows have a document reference', ok: !nodoc, detail: nodoc + ' missing' },
      { id: 'shares', label: 'Milestone shares total 100%', ok: Math.abs(share - 1) < 1e-4, detail: Math.round(share * 100) + '%' },
    ];
    const cpa = isBlank(S.cpa) ? null : { cpa: +S.cpa, diff: fromC(toC(pa) - toC(S.cpa)), ok: toC(pa) === toC(S.cpa) };
    return { checks, unverified: { n: unv, of: S.reg.length }, cpa, paid: pa };
  }

  // ---------- CSV helpers (CSV-injection safe) ----------------------------
  const csvCell = (v) => {
    let s = v == null ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = "'" + s; // neutralise spreadsheet formulas, keep plain negatives
    return '"' + s.replace(/"/g, '""') + '"';
  };
  const toCsv = (rows) => rows.map((r) => r.map(csvCell).join(',')).join('\r\n') + '\r\n';
  function periodCsv(report) {
    return toCsv([['Period', 'Income', 'Expenditure paid', 'Outstanding invoiced', 'Net (income less paid)', 'Cumulative net'],
      ...report.rows.map((r) => [r.label, r.income, r.paid, r.outstanding, r.net, r.cumulative]),
      ['Total', report.total.income, report.total.paid, report.total.outstanding, report.total.net, report.total.cumulative]]);
  }

  return {
    TOL_C, toC, fromC, rowC, RA, dd, regF, budF,
    paidBy, outBy, budBy, totalBudget, incomeTotal, paidTotal, outTotal, disbursed,
    milestoneStatus, milestoneAmountC, upcomingPayments, followUps, outstandingDue,
    dashboard, mouSchedule, grantNums, grantSummary, groupSummary, salaryBreakdown, detail, breakdown,
    periodKey, periodReport, reconciliation, csvCell, toCsv, periodCsv,
  };
});
