# GLM-CPR Financial Management System

Server-backed version of the "TEST – Financial Management System" prototype. Same screens and numbers, now with a real database, user accounts, validation and an audit trail.

## Quick start
Requires Node.js 22.13+ (uses the built-in `node:sqlite`).

```bash
npm install
npm run seed                 # opening data (add  -- --demo  for dated sample invoices/payments)
ADMIN_USER=alice ADMIN_PASSWORD='a-long-passphrase' npm run create-admin
npm start                    # http://127.0.0.1:3000
npm test                     # 45 tests
```
Environment: `PORT`, `HOST`, `DB_FILE` (default `data/gfms.sqlite`), `APP_TIMEZONE` (default `Australia/Sydney`, used for "today" in server reports), `NODE_ENV=production` (Secure cookies), `TRUST_PROXY=1` (behind a reverse proxy). **Serve over HTTPS in production.**

## Architecture
| Path | Role |
|---|---|
| `shared/finance.js` | Every calculation (totals, milestone status, periods, reconciliation). Used by the browser **and** the server, so numbers can never disagree. |
| `server/schema.sql` | Database schema. `server/db.js` applies it and wraps transactions. |
| `server/store.js` | Validation + data access + audit for every entity. |
| `server/app.js` | Express routes, auth, CSRF checks, security headers. |
| `public/` | Front-end (original look, wired to the API). |
| `tests/` | Finance maths, API, security, DB constraints, seeding, and browser (jsdom) UI tests. |

## Database (SQLite)
`settings`, `currencies`, `grants`, `countries` (one `is_bucket` row = "Global"), `workstreams`, `expense_categories` · `budget_lines` · `mous` + `mou_milestones` (3 rows each) · `transactions` (income and expenditure in one table) · `users`, `sessions`, `audit_log`.
- Money is stored as integer cents; FX is a per-row rate; reporting-currency amount = round(amount × fx).
- Reference data is by foreign key, so renaming a grant/country/workstream updates everything; in-use items cannot be deleted.
- CHECK constraints enforce: income ⇒ `Available`, expenditure ⇒ `Outstanding|Paid`, valid dates, amounts ≥ 0, FX > 0, one bucket country, one MoU per country.
- Ids are `AUTOINCREMENT` (never reused) so audit history is unambiguous.
- Opening data (`data/opening-data.json`) was extracted from the prototype: 40 budget lines, 19 MoU rows, 20 transactions, 5 grants, 13 workstreams, 197 countries.

## Roles
`viewer` read-only · `editor` + create/edit/delete transactions, budget lines, MoUs · `admin` + lists, settings, users, audit log.

## API (JSON, cookie session)
`POST /api/auth/login|logout`, `GET /api/auth/me` · `GET /api/state` · `GET /api/reports/summary?gf=&mode=month|quarter|year&fy=fy|cal` · `GET /api/reports/period.csv` · `GET /api/export/transactions.csv` · `POST/PATCH/DELETE /api/transactions[/:id]`, `/api/budget[/:id]`, `/api/mous[/:id]` · `POST/PATCH/DELETE /api/lookups/:kind` (grants|countries|works|cats|ccys) · `PUT /api/settings` · `GET/POST/PATCH /api/users` · `GET /api/audit`.
Errors: `{"error":{"message":"…","field":"amt"}}` with 401/403/404/409/422.

## Deliberate differences from the prototype
- Data lives on the server, not in `localStorage`; "Reset to opening data" was removed (use `npm run seed` on a fresh DB).
- New **Budget lines** tab (the prototype had no way to edit budgets); add-forms with validation instead of blank rows.
- Expenditure requires workstream and category; foreign-currency rows require an FX rate; payment date cannot precede invoice date.
- Salary-by-person is driven by a `staff` field instead of parsing "Salary – Name" from descriptions.
- The names "Salary" (workstream) and "Partner disbursement" (category) are protected because calculations depend on them.
- Everything user-supplied is HTML-escaped; CSV exports neutralise spreadsheet formulas.
